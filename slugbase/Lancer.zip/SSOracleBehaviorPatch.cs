﻿using RWCustom;
using System.Collections.Generic;
using System.ComponentModel;
using UnityEngine;

namespace Lancer
{
    public static class SSOracleBehaviorPatch
    {
        public static void Patch()
        {
            On.SSOracleBehavior.Update += new On.SSOracleBehavior.hook_Update(UpdatePatch);
            On.SSOracleBehavior.ThrowOutBehavior.Update += new On.SSOracleBehavior.ThrowOutBehavior.hook_Update(ThrowUpdatePatch);
            On.SSOracleBehavior.PebblesConversation.AddEvents += new On.SSOracleBehavior.PebblesConversation.hook_AddEvents(AddEventPatch);
        }

        public static void UpdatePatch(On.SSOracleBehavior.orig_Update orig, SSOracleBehavior instance, bool eu)
        {
            if (LancerMod.IsLancer && instance.inActionCounter == 299 && instance.action == SSOracleBehavior.Action.General_GiveMark && instance.player.slugcatStats.name == SlugcatStats.Name.Yellow)
            {
                instance.inActionCounter += 2;

                instance.player.mainBodyChunk.vel += Custom.RNV() * 10f;
                instance.player.bodyChunks[1].vel += Custom.RNV() * 10f;
                instance.player.Stun(40);
                (instance.oracle.room.game.session as StoryGameSession).saveState.deathPersistentSaveData.theMark = true;
                instance.oracle.room.game.GetStorySession.saveState.IncreaseKarmaCapOneStep();
                (instance.oracle.room.game.session as StoryGameSession).saveState.deathPersistentSaveData.karma = (instance.oracle.room.game.session as StoryGameSession).saveState.deathPersistentSaveData.karmaCap;
                for (int l = 0; l < instance.oracle.room.game.cameras.Length; l++)
                {
                    if (instance.oracle.room.game.cameras[l].hud.karmaMeter != null)
                    {
                        instance.oracle.room.game.cameras[l].hud.karmaMeter.UpdateGraphic();
                    }
                }
                for (int m = 0; m < 20; m++)
                {
                    instance.oracle.room.AddObject(new Spark(instance.player.mainBodyChunk.pos, Custom.RNV() * UnityEngine.Random.value * 40f, new Color(1f, 1f, 1f), null, 30, 120));
                }
                instance.oracle.room.PlaySound(SoundID.SS_AI_Give_The_Mark_Boom, 0f, 1f, 1f);
                return;
            }
            orig.Invoke(instance, eu);
        }

        public static void AddEventPatch(On.SSOracleBehavior.PebblesConversation.orig_AddEvents orig, SSOracleBehavior.PebblesConversation instance)
        {
            if (LancerMod.config.configMachine && !LancerMod.IsLancer)
            {
                orig.Invoke(instance); return;
            }
            Debug.Log("SSOracle.AddEvents patched by Lancer Mod!");
            List<Conversation.DialogueEvent> backupList = new List<Conversation.DialogueEvent>();
            for (int p = 0; p < instance.events.Count; p++)
            {
                backupList.Add(instance.events[p]);
            }
            Conversation.ID backupID = instance.id;
            instance.id = Conversation.ID.Pebbles_White;
            orig.Invoke(instance);
            //check if this is vanilla
            string check = instance.Translate("You're stuck in a cycle, a repeating pattern. You want a way out.").Substring(0, 10);
            instance.id = backupID;
            for (int c = 0; c < instance.events.Count; c++)
            {
                if (instance.events[c] is Conversation.TextEvent && (instance.events[c] as Conversation.TextEvent).text.Length > 10)
                {
                    string id = (instance.events[c] as Conversation.TextEvent).text.Substring(0, 10);
                    if (id == check) { goto lancerEvent; }
                }
            }
            //Modded
            instance.events = new List<Conversation.DialogueEvent>();
            for (int p = 0; p < backupList.Count; p++)
            {
                instance.events.Add(backupList[p]);
            }
            orig.Invoke(instance);
            //LancerMod.lancerDialogue = false;
            return;
        lancerEvent:
            Debug.Log("Using Lancer Dialogue for Pebbles: " + instance.id.ToString());
            //LancerMod.lancerDialogue = true;
            instance.events = new List<Conversation.DialogueEvent>();
            for (int p = 0; p < backupList.Count; p++)
            {
                instance.events.Add(backupList[p]);
            }
            SSOracleBehavior behavior;
            switch (instance.id)
            {
                case Conversation.ID.Pebbles_White:
                    instance.events.Add(new Conversation.TextEvent(instance, 0, ".  .  .", 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("...is this reaching you."), 15));
                    instance.events.Add(new SSOracleBehavior.PebblesConversation.PauseAndWaitForStillEvent(instance, instance.convBehav, 4));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("A tiny animal. A young one, too. Your journey has taken you deep into my chamber,<LINE>but I doubt you came here on purpose."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("I'm afraid I can't assist you in the way you would have hoped for.<LINE> I do not know what would drive you to come all the way here in search for your family... Or how you managed it."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("Your family may be long gone by now... I can assure you they are nowhere in my premises, your kind don't seem to take well to this place.<LINE>My overseers would take great delight in reporting an entire group of you, seeing how they react to just one."), 0));
                    instance.events.Add(new SSOracleBehavior.PebblesConversation.PauseAndWaitForStillEvent(instance, instance.convBehav, 20));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("However, if it's any consolation, I will give you an opportunity. To go the way of my creators. Eternal bliss, how does that sound?"), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("From here, go west past the Farm Arrays and find the place where the land fissures.<LINE>Clamber down into the earth, as deep as you can reach, and then go further."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("Saying you'll need luck is an understatement... but I admit I feel a pang of sympathy for you, and it feels wrong to leave you empty handed."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("At the end of time none of this will matter, I suppose. Even if you fail you'll live an eternity of lives more, and maybe eventually, you'll make it in the end."), 0));
                    instance.events.Add(new SSOracleBehavior.PebblesConversation.PauseAndWaitForStillEvent(instance, instance.convBehav, 4));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("Either way, you must leave now. There's a perfectly good access shaft right here."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("I hope you find what you're looking for. Don't bother coming back."), 30));
                    //instance.events.Add(new Conversation.WaitEvent(instance, 50));
                    break;

                case Conversation.ID.Pebbles_Red_Green_Neuron:
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("And so comes the second."), 0));
                    instance.events.Add(new SSOracleBehavior.PebblesConversation.PauseAndWaitForStillEvent(instance, instance.convBehav, 10));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("He was never one to think ahead. As soon as I saw him courting simple creatures with his overseer I knew whatever he was doing was foolish."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("Not too long ago the last messenger came through here. So too did it visit my can as you have.<LINE>That's just what happens when you trust wild animals to follow basic instructions."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("And on top of that, a child. He sent... a child. Was he really so desperate?<LINE>It's a miracle you even made it far enough to arrive at the wrong destination."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 10, LancerMod.Translate("I am... angered, and appalled, that he would even consider sending such a young thing on such a dangerous journey.<LINE>I admit there is a soft spot somewhere in my hardware for you young creatures."), 0));
                    instance.events.Add(new SSOracleBehavior.PebblesConversation.PauseAndWaitForStillEvent(instance, instance.convBehav, 20));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("You are not well. Like the last messenger who came here, you have something deadly festering inside you."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("You may have inherited it. Do you remember your parents? Or did he separate you when you were born?<LINE>Has... he been... breeding you? That is not a thought I can bear. I never looked upon him particularly fondly,<LINE>but this shows a side to him that I can't have imagined."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("Listen, little creature. Abandon your mission. Even if you manage to complete it, she is too far gone...<LINE>I think it's better for her to be left as she is. There is, however, still time for you to save yourself."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("I will aid you to the extent of my ability."), 0));
                    instance.events.Add(new Conversation.SpecialEvent(instance, 0, "karma"));
                    instance.events.Add(new Conversation.TextEvent(instance, 20, LancerMod.Translate("Your only hope now is to go west, past the Farm Arrays, and descend below<LINE>the earth to as far as you can reach. Your only salvation lies there."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("I can't help you anymore than this, despite my purpose and power. I couldn't even help myself."), 10));
                    instance.events.Add(new SSOracleBehavior.PebblesConversation.PauseAndWaitForStillEvent(instance, instance.convBehav, 4));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("I will keep these slag keys. I guarantee I have more use for them than she would.<LINE>Please hurry, little one. I only want the best for you."), 30));
                    lunterStoleNeuron = false; secondEntry = true; banned = false;
                    behavior = instance.owner;
                    greenNeuron = behavior.greenNeuron;
                    break;

                case Conversation.ID.Pebbles_Red_No_Neuron:
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("As I feared, here you are. Empty handed."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("He was never one to think ahead. As soon as I saw him coercing simple creatures with his overseer I knew whatever he was doing was foolish."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("Not so long ago the last messenger came through here. So too did it visit my can as you have.<LINE>Though at least that one didn't lose its payload."), 15));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("What else to expect from a pup. What else did he think would happen?<LINE>Not only did you abandon the delivery, you managed to travel<LINE>a more treacherous path to the wrong destination."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("I'm having trouble choosing which to be more angry over, his reckless and<LINE>desperate endangerment of a child, or the fact that you came all this way for nothing..."), 0));
                    instance.events.Add(new SSOracleBehavior.PebblesConversation.PauseAndWaitForStillEvent(instance, instance.convBehav, 20));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("Tiny creature, you are not healthy. We are bearers of similar ailments, you and I."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("It is a shame you have to deal with this sickness at such a young age. I would not feel right if I didn't try to help in any way I can."), 0));
                    instance.events.Add(new Conversation.SpecialEvent(instance, 0, "karma"));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("I hope I have repaid what little time you have left that was spent coming here."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("You can use your remaining time for a greater purpose, however. There is still a chance for your salvation, little one.<LINE>Go west, past the Farm Arrays, and descend below the earth as far as you can reach. There you will find a solution to<LINE>a problem that has afflicted everything since the beginning of time."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("You'd only be helping yourself, though. Sadly my kind are the only ones left in this world<LINE>who can do something about that. Either way, it's time for you to go."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("Please stay safe, child. This may be your best shot at ascension in one thousand thousand lifetimes. It'd be a shame to waste it."), 30));
                    lunterStoleNeuron = true; secondEntry = true; banned = true;
                    break;

                case Conversation.ID.Pebbles_Yellow:
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("Should I start leaving a cushion under my access shafts? If visits from you things are going to be so frequent, why not make it a bit more comfortable?"), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("Time and time again, young and old, your kind manage to wander through my systems and across my exterior<LINE>until they end up here, and every time I help them and they go on their way."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("Is this what has become of me? A simple a slug-attunement device? That's all I do nowadays, after all!"), 0));
                    instance.events.Add(new SSOracleBehavior.PebblesConversation.PauseAndWaitForStillEvent(instance, instance.convBehav, 4));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("It wouldn't be fair to punish you from the outset because of what your predecessors have done.<LINE>So I will give you the instructions I gave them, to use the Mark you now hold. But after that,<LINE>use whatever pheromones, metal-pounding, or guttural yowls your kind utilizes to relay a simple message."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 10, LancerMod.Translate("Don't. Come. Back. This goes for you too, little one. If you come back, I will kill you."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("Now, let's get you on your way. Go west, past the Farm Arrays. Where the land fissures, go down into the earth and search your way deeper."), 0));
                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("Did you get all of that? Good. Leave."), 30));
                    break;
            }
        }

        public static NSHSwarmer greenNeuron;
        public static bool lunterStoleNeuron = true; public static bool secondEntry = true;
        public static bool banned = false;

        public static void ThrowUpdatePatch(On.SSOracleBehavior.ThrowOutBehavior.orig_Update orig, SSOracleBehavior.ThrowOutBehavior instance)
        {
            //!LancerMod.lancerDialogue ||
            if (LancerMod.config.configMachine && !LancerMod.IsLancer) { orig.Invoke(instance); return; }
            if (instance.owner.oracle.room.game.StoryCharacter == 0)
            {
                orig.Invoke(instance); return;
            }
            else if (instance.owner.oracle.room.game.StoryCharacter == 1)
            { //monk
                goto Lonk;
            }

            Vector2 GrabPos = (instance.oracle.graphicsModule == null) ? instance.oracle.firstChunk.pos : (instance.oracle.graphicsModule as OracleGraphics).hands[1].pos;

            if (instance.player.room == instance.oracle.room)
            {
                if (!lunterStoleNeuron && greenNeuron?.room == instance.oracle.room)
                {
                    instance.owner.greenNeuron = greenNeuron;
                    if (instance.owner.greenNeuron != null && instance.owner.greenNeuron.grabbedBy.Count < 1)
                    {
                        //instance.player.mainBodyChunk.vel *= Mathf.Lerp(0.9f, 1f, instance.oracle.room.gravity);
                        //instance.player.bodyChunks[1].vel *= Mathf.Lerp(0.9f, 1f, instance.oracle.room.gravity);
                        //instance.player.mainBodyChunk.vel += Custom.DirVec(instance.player.mainBodyChunk.pos, instance.owner.greenNeuron.firstChunk.pos)
                        //    * 0.5f * (1f - instance.oracle.room.gravity);
                        instance.owner.greenNeuron.firstChunk.MoveFromOutsideMyUpdate(true, GrabPos);
                        instance.owner.greenNeuron.firstChunk.vel *= 0f;
                        instance.owner.greenNeuron.direction = Custom.PerpendicularVector(instance.oracle.firstChunk.pos, instance.owner.greenNeuron.firstChunk.pos);
                        instance.owner.greenNeuron.storyFly = true;
                        if (instance.owner.greenNeuron.storyFly)
                        {
                            instance.owner.greenNeuron.storyFlyTarget = GrabPos;
                            if (Custom.DistLess(instance.owner.greenNeuron.firstChunk.pos, instance.player.firstChunk.pos, 40f))
                            {
                                instance.player.ReleaseGrasp(1);
                                instance.player.SlugcatGrab(instance.owner.greenNeuron, 1);
                            }
                        }
                    }
                    if (instance.owner.greenNeuron != null && instance.owner.greenNeuron.grabbedBy.Count > 0 && instance.owner.greenNeuron.grabbedBy[0].grabber is Player)
                    {
                        instance.owner.greenNeuron.storyFly = false;
                        lunterStoleNeuron = true;
                        instance.telekinThrowOut = false;
                        instance.owner.NewAction(SSOracleBehavior.Action.ThrowOut_ThrowOut);
                        instance.owner.throwOutCounter = 0;
                        banned = false;
                        greenNeuron = null;
                    }
                }

                if (instance.telekinThrowOut && !instance.oracle.room.aimap.getAItile(instance.player.mainBodyChunk.pos).narrowSpace)
                {
                    instance.player.mainBodyChunk.vel += Custom.DirVec(instance.player.mainBodyChunk.pos, instance.oracle.room.MiddleOfTile(28, 32))
                        * 0.25f * (1f - instance.oracle.room.gravity) * Mathf.InverseLerp(220f, 280f, (float)instance.inActionCounter);
                }
            }

            switch (instance.action)
            {
                case SSOracleBehavior.Action.ThrowOut_ThrowOut:
                    if (banned) { banned = false; instance.owner.NewAction(SSOracleBehavior.Action.ThrowOut_Polite_ThrowOut); return; }
                    //stolen neuron
                    if (instance.player.room == instance.oracle.room)
                    {
                        instance.owner.throwOutCounter++;
                    }
                    instance.movementBehavior = SSOracleBehavior.MovementBehavior.KeepDistance;
                    instance.telekinThrowOut = (instance.owner.throwOutCounter > 1150);
                    if (instance.owner.throwOutCounter == 50)
                    {
                        instance.dialogBox.Interrupt(LancerMod.Translate("What? Why would you take it back? Do you even know where you're going with that?"), 0);
                    }
                    else if (instance.owner.throwOutCounter == 250)
                    {
                        instance.dialogBox.Interrupt(LancerMod.Translate("Fine, little creature. Have it your way. Her name is Looks to the Moon, and she lies decrepit in the waters to the east."), 0);
                    }
                    if (instance.owner.throwOutCounter == 700)
                    {
                        instance.dialogBox.Interrupt(LancerMod.Translate("It's a shame you'd choose to waste such a precious resource on her.<LINE>But I respect your courage, and if you feel that's what's right, I won't stand in your way."), 0);
                    }
                    else if (instance.owner.throwOutCounter == 1200)
                    {
                        instance.telekinThrowOut = true;
                        instance.dialogBox.Interrupt(LancerMod.Translate("Leave now, and don't come back."), 0);
                        banned = true;
                        instance.owner.NewAction(SSOracleBehavior.Action.ThrowOut_SecondThrowOut);
                    }
                    if (instance.owner.playerOutOfRoomCounter > 100 && instance.owner.throwOutCounter > 400)
                    {
                        instance.owner.NewAction(SSOracleBehavior.Action.General_Idle);
                        instance.owner.getToWorking = 1f;
                    }
                    break;

                case SSOracleBehavior.Action.ThrowOut_Polite_ThrowOut:
                    instance.owner.getToWorking = 1f;
                    instance.telekinThrowOut = instance.inActionCounter > 1200;
                    if (instance.inActionCounter < 530)
                    {
                        instance.movementBehavior = SSOracleBehavior.MovementBehavior.Idle;
                    }
                    else if (instance.inActionCounter < 1050)
                    {
                        instance.movementBehavior = SSOracleBehavior.MovementBehavior.Investigate;
                    }
                    else
                    {
                        instance.movementBehavior = SSOracleBehavior.MovementBehavior.Talk;
                    }
                    if (instance.owner.playerOutOfRoomCounter > 100 && instance.inActionCounter > 400)
                    {
                        instance.owner.NewAction(SSOracleBehavior.Action.General_Idle);
                    }
                    else if (instance.inActionCounter == 1100)
                    {
                        instance.dialogBox.NewMessage(LancerMod.Translate("Do you need some help, tiny creature?"), 0);
                    }
                    //if (lunterStoleNeuron) { instance.owner.NewAction(SSOracleBehavior.Action.ThrowOut_ThrowOut); }
                    break;

                case SSOracleBehavior.Action.ThrowOut_SecondThrowOut:
                    if (instance.player.room == instance.oracle.room)
                    {
                        instance.owner.throwOutCounter++;
                    }
                    instance.movementBehavior = SSOracleBehavior.MovementBehavior.Investigate;
                    instance.telekinThrowOut = (instance.inActionCounter > 220) && secondEntry || (banned && instance.inActionCounter > 50);
                    if (!banned && instance.owner.throwOutCounter == 50)
                    {
                        if (!lunterStoleNeuron && secondEntry)
                        {
                            instance.dialogBox.Interrupt(LancerMod.Translate("Why have you returned? There is nothing left for you here."), 0);
                        }
                        else if (lunterStoleNeuron && secondEntry)
                        {
                            instance.dialogBox.Interrupt(LancerMod.Translate("I implore you, little creature, for the sake of both of us, to just leave already."), 0);
                        }
                        else
                        {
                            instance.telekinThrowOut = false;
                            instance.dialogBox.Interrupt(LancerMod.Translate("Well, child, if you'd rather spend time with me than search for eternal happiness, I will gladly accommodate you."), 0);
                        }
                    }
                    else if (!banned && instance.owner.throwOutCounter == 250)
                    {
                        if (!lunterStoleNeuron && secondEntry)
                        {
                            instance.dialogBox.Interrupt(LancerMod.Translate("Please don't waste any more of your time, little creature."), 0);
                        }
                        else if (lunterStoleNeuron && secondEntry)
                        {
                            instance.dialogBox.Interrupt(LancerMod.Translate("I cannot assist you further."), 0);
                        }
                        else
                        {
                            instance.dialogBox.Interrupt(LancerMod.Translate("Just be aware of the mistake you're making."), 0);
                            instance.owner.getToWorking = 1f;
                        }
                    }
                    else if (!banned && instance.owner.throwOutCounter == 700)
                    {
                        if (!lunterStoleNeuron && secondEntry)
                        {
                            instance.dialogBox.Interrupt(LancerMod.Translate("It is too long a journey to stall for even a second."), 0);
                        }
                    }
                    if (instance.owner.playerOutOfRoomCounter > 100 && instance.owner.throwOutCounter > 400)
                    {
                        instance.owner.NewAction(SSOracleBehavior.Action.General_Idle);
                        instance.owner.getToWorking = 1f;
                    }
                    break;

                case SSOracleBehavior.Action.ThrowOut_KillOnSight:
                    if (instance.player.room == instance.oracle.room)
                    {
                        secondEntry = false;
                        instance.owner.NewAction(SSOracleBehavior.Action.ThrowOut_SecondThrowOut);
                    }
                    break;

                default:
                    orig.Invoke(instance);
                    break;
            }
            return;

        Lonk:
            switch (instance.action)
            {
                case SSOracleBehavior.Action.ThrowOut_ThrowOut:
                    orig.Invoke(instance);
                    break;

                case SSOracleBehavior.Action.ThrowOut_SecondThrowOut:
                    if (instance.player.room == instance.oracle.room)
                    {
                        instance.owner.throwOutCounter++;
                    }
                    instance.movementBehavior = SSOracleBehavior.MovementBehavior.Idle;
                    instance.telekinThrowOut = (instance.inActionCounter > 50);
                    if (instance.owner.throwOutCounter == 300)
                    {
                        instance.owner.NewAction(SSOracleBehavior.Action.ThrowOut_KillOnSight);
                    }
                    break;

                case SSOracleBehavior.Action.ThrowOut_KillOnSight:
                    orig.Invoke(instance);
                    break;

                default:
                    orig.Invoke(instance);
                    break;
            }
        }
    }
}