﻿using RWCustom;
using UnityEngine;

namespace Lancer
{
    public static partial class PlayerPatch
    {
        public class MaskOnHorn
        {
            public MaskOnHorn(Player owner)
            {
                this.owner = owner;
            }

            public Player owner;
            public VultureMask mask;
            public bool increment;
            public int counter;
            public bool interactionLocked;
            public PlayerPatch.AbstractOnHornStick abstractStick;

            public Color color;
            public Color blackColor;
            public HSLColor ColorA;
            public HSLColor ColorB;

            public bool HasAMask
            {
                get
                {
                    return this.mask != null;
                }
            }

            public void Update(bool eu)
            {
                if (!this.interactionLocked && this.increment)
                {
                    this.counter++;
                    if (this.mask != null && this.counter > 20)
                    {
                        this.MaskToHand(eu);
                        this.counter = 0;
                    }
                    else if (this.mask == null && this.counter > 20)
                    {
                        for (int i = 0; i < 2; i++)
                        {
                            if (this.owner.grasps[i] != null && this.owner.grasps[i].grabbed is VultureMask)
                            {
                                this.owner.bodyChunks[0].pos += Custom.DirVec(this.owner.grasps[i].grabbed.firstChunk.pos, this.owner.bodyChunks[0].pos) * 2f;
                                this.MaskToHorn(this.owner.grasps[i].grabbed as VultureMask);
                                this.counter = 0;
                                break;
                            }
                        }
                    }
                }
                else
                {
                    this.counter = 0;
                }
                if (!this.owner.input[0].pckp)
                {
                    this.interactionLocked = false;
                }
                this.increment = false;
            }

            public void GraphicsModuleUpdated(bool actuallyViewed, bool eu)
            {
                if (this.mask == null) { return; }
                if (this.mask.slatedForDeletetion)
                {
                    if (this.abstractStick != null)
                    {
                        this.abstractStick.Deactivate();
                    }
                    this.mask = null;
                    return;
                }
                Vector2 pos0 = this.owner.mainBodyChunk.pos;
                //Vector2 pos1 = this.owner.bodyChunks[1].pos;
                Vector2 vel0 = this.owner.mainBodyChunk.vel;
                if (this.owner.graphicsModule != null && actuallyViewed)
                {
                    pos0 = (this.owner.graphicsModule as PlayerGraphics).head.pos;
                    vel0 = (this.owner.graphicsModule as PlayerGraphics).head.vel;
                    //pos1 = (this.owner.graphicsModule as PlayerGraphics).drawPositions[1, 0];
                }

                float to = Custom.LerpMap(this.owner.eatCounter, 35f, 15f, 0f, 10f);
                float to2 = 0f;
                mask.CollideWithTerrain = false;
                mask.CollideWithObjects = false;
                if (this.owner.standing && (this.owner.bodyMode != Player.BodyModeIndex.ClimbingOnBeam || this.owner.animation == Player.AnimationIndex.StandOnBeam)
                    && this.owner.bodyMode != Player.BodyModeIndex.Swimming)
                {
                    if (this.owner.input[0].x != 0 && Mathf.Abs(this.owner.bodyChunks[1].lastPos.x - this.owner.bodyChunks[1].pos.x) > 2f)
                    {
                        to2 = (float)this.owner.input[0].x;
                    }
                }
                //if (dir.y < 0) { dir.y = -dir.y; }
                this.vel -= Mathf.Max(Mathf.Abs(this.rot), 5f) * Mathf.Sign(this.rot) * this.mask.room.gravity;
                this.vel += vel0.x * 9f * (this.mask.room.gravity * 0.5f + 0.5f);
                this.vel *= 0.95f;
                if (to2 != 0f && UnityEngine.Random.value < 0.05f)
                {
                    this.rot += to2 * UnityEngine.Random.value * 30f;
                }
                this.rot += this.vel;
                if (this.rot < 1f) { this.rot = 0f; }
                if (this.vel < 1f) { this.vel = 0f; }
                Vector2 dir = Custom.RotateAroundOrigo(new Vector2(0f, 1f), this.rot);
                //dir *= Mathf.Sign(Custom.DistanceToLine(mask.firstChunk.pos, this.owner.bodyChunks[0].pos, this.owner.bodyChunks[1].pos));
                //dir = Custom.RotateAroundOrigo(dir, to2 * -30f);

                mask.firstChunk.MoveFromOutsideMyUpdate(eu, pos0);
                mask.firstChunk.vel = this.owner.mainBodyChunk.vel;
                mask.rotationA = Vector3.Slerp(mask.rotationA, dir, 0.5f);
                mask.rotationB = new Vector2(0f, 1f);
                mask.donned = Custom.LerpAndTick(mask.donned, to, 0.11f, 0.0333333351f);
                mask.viewFromSide = Custom.LerpAndTick(mask.viewFromSide, to2, 0.11f, 0.0333333351f);
                mask.Forbid();
            }

            private float vel;
            private float rot;

            public void MaskToHand(bool eu)
            {
                if (this.mask == null)
                {
                    return;
                }
                for (int i = 0; i < 2; i++)
                {
                    if (this.owner.grasps[i] != null)
                    {
                        if ((int)this.owner.Grabability(this.owner.grasps[i].grabbed) >= 3) { return; }
                    }
                }
                int num = -1;
                int num2 = 0;
                while (num2 < 2 && num == -1)
                {
                    if (this.owner.grasps[num2] == null)
                    {
                        num = num2;
                    }
                    num2++;
                }
                if (num == -1)
                {
                    return;
                }
                if (this.owner.graphicsModule != null)
                {
                    this.mask.firstChunk.MoveFromOutsideMyUpdate(eu, (this.owner.graphicsModule as PlayerGraphics).hands[num].pos);
                }
                this.owner.SlugcatGrab(this.mask, num);
                this.mask = null;
                this.interactionLocked = true;
                this.owner.noPickUpOnRelease = 20;
                this.owner.room.PlaySound(SoundID.Vulture_Mask_Pick_Up, this.owner.mainBodyChunk);
                if (this.abstractStick != null)
                {
                    this.abstractStick.Deactivate();
                    this.abstractStick = null;
                }
            }

            public void MaskToHorn(VultureMask mask)
            {
                if (this.mask != null)
                {
                    return;
                }
                for (int i = 0; i < 2; i++)
                {
                    if (this.owner.grasps[i] != null && this.owner.grasps[i].grabbed == mask)
                    {
                        this.owner.ReleaseGrasp(i);
                        //mask.grabbedBy[0] = new Creature.Grasp(this.owner, mask, i, 0, Creature.Grasp.Shareability.CanNotShare, 1f, true);
                        break;
                    }
                }
                this.mask = mask;
                this.color = mask.color;
                this.blackColor = mask.blackColor;
                this.ColorA = mask.ColorA;
                this.ColorB = mask.ColorB;

                //this.mask.ChangeMode(Weapon.Mode.OnBack);
                this.interactionLocked = true;
                this.owner.noPickUpOnRelease = 20;
                this.owner.room.PlaySound(SoundID.Slugcat_Stash_Spear_On_Back, this.owner.mainBodyChunk);
                if (this.abstractStick != null)
                {
                    this.abstractStick.Deactivate();
                }
                this.abstractStick = new PlayerPatch.AbstractOnHornStick(this.owner.abstractPhysicalObject, this.mask.abstractPhysicalObject);
                this.rot = 0f;
                this.vel = 0f;
            }

            public void DropMask()
            {
                if (this.mask == null)
                {
                    return;
                }
                this.mask.firstChunk.vel = this.owner.mainBodyChunk.vel + Custom.RNV() * 3f * UnityEngine.Random.value;
                this.mask = null;
                if (this.abstractStick != null)
                {
                    this.abstractStick.Deactivate();
                    this.abstractStick = null;
                }
            }
        }
    }
}