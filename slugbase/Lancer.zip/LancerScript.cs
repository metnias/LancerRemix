using Partiality.Modloader;
using UnityEngine;

namespace Lancer
{
    public class LancerScript : MonoBehaviour
    {
        public static LancerMod mod;
        public static RainWorld rw;
        public static ProcessManager pm;

        // public const BindingFlags flagInst = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;

        public void Initialize()
        {
            LancerMod.script = this;

            PlayerPatch.Patch();
            TutorialPatch.Patch();
            SpearPatch.Patch();
            CreaturePatch.Patch();
            PlayerGraphicsPatch.Patch();
            VulturePatch.Patch();
            SSOracleBehaviorPatch.Patch();
            SLOracleBehaviorPatch.Patch();
            ProcessManagerPatch.Patch();
        }

        public static void GarbageCollect()
        {
            SpearPatch.SpearBeamStates.Clear();
            CreaturePatch.MoreHealthStates.Clear();
        }

#pragma warning disable CA1822

        public void Update()
        {
            if (rw == null)
            {
                rw = UnityEngine.Object.FindObjectOfType<RainWorld>();
                pm = rw.processManager;

                if (rw != null)
                {
                    CheckCollision();
                }
            }
            return;
        }

        private static void CheckCollision()
        {
            foreach (PartialityMod m in Partiality.PartialityManager.Instance.modManager.loadedMods)
            {
                if (m != mod && m.isEnabled && m.ModID == mod.ModID) //Collision!
                {
                    string e = "Lancer: You have installed Lancer Mod twice! Delete NOCM version!";
                    Debug.Log(e);
                    Debug.LogError(e);
                    LancerMod.config.disabled = !LancerMod.config.configMachine; return;
                }
            }
        }
    }
}