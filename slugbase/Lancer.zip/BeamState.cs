﻿namespace Lancer
{
    public static partial class SpearPatch
    {
        public struct BeamState
        {
            public byte used;

            public bool isHorizontal;
            public bool addPoles;
            public bool[] wasBeam;
            public bool hasBeamState;

            public bool slideThrown;
        }
    }
}