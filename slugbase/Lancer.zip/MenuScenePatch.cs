﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using System.IO;
using RWCustom;
using System.Reflection;
using Menu;

namespace Lancer
{
    public static class MenuScenePatch
    {
        public static void BuildScenePatch(On.Menu.MenuScene.orig_BuildScene orig, MenuScene scene)
        {
            if (scene.sceneID != MenuScene.SceneID.SleepScreen)
            {
                orig.Invoke(scene); return;
            }
            if (scene is InteractiveMenuScene)
            {
                (scene as InteractiveMenuScene).idleDepths = new List<float>();
            }

            scene.AddIllustration(new MenuDepthIllustration(scene.menu, scene, "Lancer", "Test", new Vector2(523f, 17f), 3.5f, MenuDepthIllustration.MenuShader.Normal));
            scene.AddIllustration(new MenuDepthIllustration(scene.menu, scene, "Lancer", "Test", new Vector2(523f, 17f), 2.8f, MenuDepthIllustration.MenuShader.Normal));
            scene.AddIllustration(new MenuDepthIllustration(scene.menu, scene, "Lancer", "TestDepth", new Vector2(523f, 17f), 1.7f, MenuDepthIllustration.MenuShader.Normal));

            /*
            scene.sceneFolder = "Scenes" + Path.DirectorySeparatorChar + "Slugcat - White";
            scene.AddIllustration(new MenuDepthIllustration(scene.menu, scene, scene.sceneFolder, "White Background - 5", new Vector2(0f, 0f), 3.6f, MenuDepthIllustration.MenuShader.Normal));
            scene.AddIllustration(new MenuDepthIllustration(scene.menu, scene, scene.sceneFolder, "White Haze - 4", new Vector2(0f, 0f), 3.2f, MenuDepthIllustration.MenuShader.Lighten));
            scene.depthIllustrations[scene.depthIllustrations.Count - 1].setAlpha = new float?(0.3f);
            scene.AddIllustration(new MenuDepthIllustration(scene.menu, scene, scene.sceneFolder, "White BkgPlants - 3", new Vector2(0f, 0f), 3.1f, MenuDepthIllustration.MenuShader.Normal));
            scene.AddIllustration(new MenuDepthIllustration(scene.menu, scene, scene.sceneFolder, "White Vines - 1", new Vector2(0f, 0f), 2.8f, MenuDepthIllustration.MenuShader.Normal));
            if (scene.owner is SlugcatSelectMenu.SlugcatPage)
            {
                (scene.owner as SlugcatSelectMenu.SlugcatPage).AddGlow();
            }
            scene.AddIllustration(new MenuDepthIllustration(scene.menu, scene, "Lancer", "Test", new Vector2(683f, 384f), 2.7f, MenuDepthIllustration.MenuShader.Normal));
            scene.AddIllustration(new MenuDepthIllustration(scene.menu, scene, scene.sceneFolder, "White FgPlants - 0", new Vector2(0f, 0f), 2.1f, MenuDepthIllustration.MenuShader.Normal));
            (scene as InteractiveMenuScene).idleDepths.Add(3.6f);
            (scene as InteractiveMenuScene).idleDepths.Add(2.8f);
            (scene as InteractiveMenuScene).idleDepths.Add(2.7f);
            (scene as InteractiveMenuScene).idleDepths.Add(2.6f);
            (scene as InteractiveMenuScene).idleDepths.Add(1.5f);*/
        }

        public static void IllustLoadPatch(On.Menu.MenuIllustration.orig_LoadFile_1 orig, MenuIllustration instance, string folder)
        {
            if (folder != "Lancer")
            {
                orig.Invoke(instance, folder);
                return;
            }

            var assembly = Assembly.GetExecutingAssembly();
            string resourceName = string.Concat("Lancer.Scene.", instance.fileName, ".txt");
            string result;
            byte[] bytes;

            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            using (StreamReader reader = new StreamReader(stream))
            {
                result = reader.ReadToEnd();
            }
            bytes = System.Convert.FromBase64String(result);

            Texture2D texture = new Texture2D(1, 1, TextureFormat.ARGB32, false);
            texture.wrapMode = TextureWrapMode.Clamp;
            if ((bool)typeof(MenuIllustration).GetField("crispPixels", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).GetValue(instance))
            {
                texture.anisoLevel = 0;
                texture.filterMode = FilterMode.Point;
            }
            texture.LoadImage(bytes);
            HeavyTexturesCache.LoadAndCacheAtlasFromTexture(instance.fileName, texture);
            typeof(MenuIllustration).GetField("texture", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).SetValue(instance, texture);
            typeof(MenuIllustration).GetField("www", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).SetValue(instance, null);
        }

        public static void EncodeExteriorPNG()
        {
            string[] files = Directory.GetFiles(Path.Combine(Directory.GetParent(Application.dataPath).ToString(), "encode") + Path.DirectorySeparatorChar.ToString(), "*.png", SearchOption.TopDirectoryOnly);
            foreach (string path in files)
            {
                try
                {
                    byte[] bytes = File.ReadAllBytes(path);
                    string encode = System.Convert.ToBase64String(bytes);
                    string newPath = path.Replace("png", "txt");

                    File.WriteAllText(newPath, encode);
                }
                catch (Exception ex)
                {
                    Debug.LogError(string.Concat("error while encoding ", path));
                    Debug.LogError(ex);
                }
            }
        }
    }
}

/*

namespace Menu
{
    public class patch_MenuScene : MenuScene
    {
        [MonoModIgnore]
        public patch_MenuScene(Menu menu, MenuObject owner, MenuScene.SceneID sceneID) : base(menu, owner, sceneID)
        {
        }

        public extern void orig_ctor(Menu menu, MenuObject owner, MenuScene.SceneID sceneID);
        [MonoModConstructor]
        public void ctor(Menu menu, MenuObject owner, MenuScene.SceneID sceneID) { orig_ctor(menu, owner, sceneID); }

        public extern void orig_BuildScene();
        public void BuildScene()
        {
            if(this.sceneID != SceneID.SleepScreen)
            {
                orig_BuildScene();
                return;
            }

            NewSleepScreen:
            int num;
            if (this.menu.manager.currentMainLoop is RainWorldGame)
            {
                num = (this.menu.manager.currentMainLoop as RainWorldGame).StoryCharacter;
            }
            else
            {
                num = this.menu.manager.rainWorld.progression.PlayingAsSlugcat;
            }
            string text = "White";
            if (num != 0)
            {
                text = ((num != 1) ? "Red" : "Yellow");
            }
            this.sceneFolder = string.Concat(new object[]
            {
                    "Scenes",
                    Path.DirectorySeparatorChar,
                    "Sleep Screen - ",
                    text
            });

            this.AddIllustration(new MenuDepthIllustration(this.menu, this, "Rainbow", "Test", new Vector2(23f, 17f), 3.5f, MenuDepthIllustration.MenuShader.Normal));
            this.AddIllustration(new MenuDepthIllustration(this.menu, this, "Rainbow", "Test", new Vector2(23f, 17f), 2.8f, MenuDepthIllustration.MenuShader.Normal));
            this.AddIllustration(new MenuDepthIllustration(this.menu, this, "Rainbow", "TestDepth", new Vector2(23f, 17f), 1.7f, MenuDepthIllustration.MenuShader.Normal));

            ///
            if (this.flatMode)
            {
                this.AddIllustration(new MenuIllustration(this.menu, this, this.sceneFolder, "Sleep Screen - " + text + " - Flat", new Vector2(683f, 384f), false, true));
            }
            else
            {
                this.AddIllustration(new MenuDepthIllustration(this.menu, this, this.sceneFolder, "Sleep - 5", new Vector2(23f, 17f), 3.5f, MenuDepthIllustration.MenuShader.Normal));
                this.AddIllustration(new MenuDepthIllustration(this.menu, this, this.sceneFolder, "Sleep - 4", new Vector2(23f, 17f), 2.8f, MenuDepthIllustration.MenuShader.Normal));
                this.depthIllustrations[this.depthIllustrations.Count - 1].setAlpha = new float?(0.24f);
                this.AddIllustration(new MenuDepthIllustration(this.menu, this, this.sceneFolder, "Sleep - 3", new Vector2(23f, 17f), 2.2f, MenuDepthIllustration.MenuShader.Normal));
                this.AddIllustration(new MenuDepthIllustration(this.menu, this, this.sceneFolder, "Sleep - 2 - " + text, new Vector2(23f, 17f), 1.7f, MenuDepthIllustration.MenuShader.Normal));
                this.AddIllustration(new MenuDepthIllustration(this.menu, this, this.sceneFolder, "Sleep - 1", new Vector2(23f, 17f), 1.2f, MenuDepthIllustration.MenuShader.Normal));
                ((this as MenuScene) as InteractiveMenuScene).idleDepths.Add(3.3f);
                ((this as MenuScene) as InteractiveMenuScene).idleDepths.Add(2.7f);
                ((this as MenuScene) as InteractiveMenuScene).idleDepths.Add(1.8f);
                ((this as MenuScene) as InteractiveMenuScene).idleDepths.Add(1.7f);
                ((this as MenuScene) as InteractiveMenuScene).idleDepths.Add(1.6f);
                ((this as MenuScene) as InteractiveMenuScene).idleDepths.Add(1.2f);
            }
            ///
        }
    }

    public class patch_MenuIllustration : MenuIllustration
{
    [MonoModIgnore]
    public patch_MenuIllustration(Menu menu, MenuObject owner, string folderName, string fileName, Vector2 pos, bool crispPixels, bool anchorCenter) : base(menu, owner, folderName, fileName, pos, crispPixels, anchorCenter)
    {
    }

    public extern void orig_ctor(Menu menu, MenuObject owner, string folderName, string fileName, Vector2 pos, bool crispPixels, bool anchorCenter);
    [MonoModConstructor]
    public void ctor(Menu menu, MenuObject owner, string folderName, string fileName, Vector2 pos, bool crispPixels, bool anchorCenter)
    {
        orig_ctor(menu, owner, folderName, fileName, pos, crispPixels, anchorCenter);
    }

    public extern void orig_LoadFile(string Folder);
    public new void LoadFile(string folder)
    {
        if (folder != "Rainbow")
        {
            orig_LoadFile(folder);
            return;
        }

        var assembly = Assembly.GetExecutingAssembly();
        string resourceName = string.Concat("Rainbow.Scene.", this.fileName, ".txt");
        string result;
        byte[] bytes;

        using (Stream stream = assembly.GetManifestResourceStream(resourceName))
        using (StreamReader reader = new StreamReader(stream))
        {
            result = reader.ReadToEnd();
        }
        bytes = System.Convert.FromBase64String(result);

        this.texture = new Texture2D(1, 1, TextureFormat.ARGB32, false);

        this.texture.wrapMode = TextureWrapMode.Clamp;
        if (this.crispPixels)
        {
            this.texture.anisoLevel = 0;
            this.texture.filterMode = FilterMode.Point;
        }
        this.texture.LoadImage(bytes);
        HeavyTexturesCache.LoadAndCacheAtlasFromTexture(this.fileName, this.texture);
        this.www = null;
    }

    [MonoModIgnore]
    public bool crispPixels;
}
}

 */ 