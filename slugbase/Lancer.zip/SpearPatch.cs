using RWCustom;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace Lancer
{
    public static partial class SpearPatch
    {
        public static void Patch()
        {
            On.AbstractSpear.ctor += new On.AbstractSpear.hook_ctor(AbsSpearCtorPatch);
            On.AbstractPhysicalObject.Destroy += new On.AbstractPhysicalObject.hook_Destroy(AbsObjDestroyPatch);
            On.Spear.PlaceInRoom += new On.Spear.hook_PlaceInRoom(PlaceRoomPatch);
            On.Spear.HitSomething += new On.Spear.hook_HitSomething(HitPatch);
            On.Spear.ChangeMode += new On.Spear.hook_ChangeMode(ChangeModePatch);
            On.Spear.Update += new On.Spear.hook_Update(UpdatePatch);
            On.Spear.LodgeInCreature += new On.Spear.hook_LodgeInCreature(LodgeCreaturePatch);
            On.Spear.DrawSprites += new On.Spear.hook_DrawSprites(DrawSprPatch);
            On.Spear.PickedUp += new On.Spear.hook_PickedUp(PickUpPatch);

            SpearBeamStates = new Dictionary<AbstractSpear, BeamState>();
        }

        public static Dictionary<AbstractSpear, BeamState> SpearBeamStates;

        public static void UpdateBeamState(AbstractSpear spear, BeamState newState)
        {
            do
            {
                SpearBeamStates.Remove(spear);
            } while (SpearBeamStates.ContainsKey(spear));
            SpearBeamStates.Add(spear, newState);
            // Debug.Log(string.Concat("Lancer SpearStates Count: ", SpearBeamStates.Count));
        }

        public static void UpdateBeamState(Spear spear, BeamState newState)
        {
            UpdateBeamState(spear.abstractSpear, newState);
        }

        public static void AbsSpearCtorPatch(On.AbstractSpear.orig_ctor orig, AbstractSpear spear, World world, Spear realizedObject, WorldCoordinate pos, EntityID ID, bool explosive)
        {
            orig.Invoke(spear, world, realizedObject, pos, ID, explosive);
            if (!LancerMod.config.canPullSpear && !LancerMod.IsMelee) { return; }
            if (explosive) { return; }

            if (SpearBeamStates.ContainsKey(spear)) { return; } //already existing state
            BeamState beamState = new BeamState
            {
                wasBeam = new bool[3],
                used = 8,
                slideThrown = false
            };

            SpearBeamStates.Add(spear, beamState);
        }

        public static void AbsObjDestroyPatch(On.AbstractPhysicalObject.orig_Destroy orig, AbstractPhysicalObject obj)
        {
            orig.Invoke(obj);
            if (obj is AbstractSpear && SpearBeamStates.ContainsKey(obj as AbstractSpear))
            { SpearBeamStates.Remove(obj as AbstractSpear); }
        }

        public static void PlaceRoomPatch(On.Spear.orig_PlaceInRoom orig, Spear spear, Room placeRoom)
        {
            orig.Invoke(spear, placeRoom);

            if (!LancerMod.config.canPullSpear && !LancerMod.IsMelee) { return; }
            if (spear is ExplosiveSpear) { return; }

            if (!SpearBeamStates.TryGetValue(spear.abstractSpear, out BeamState beamState))
            {
                beamState = new BeamState
                {
                    wasBeam = new bool[3],
                    used = 8,
                    slideThrown = false
                };
            }
            else { SpearBeamStates.Remove(spear.abstractSpear); }

            if (spear.abstractSpear.stuckInWall)
            {
                beamState.hasBeamState = true;
                //beamState.used = (byte)(beamState.used < 12 ? beamState.used + 12 : beamState.used);
                beamState.isHorizontal = spear.abstractSpear.stuckInWallCycles >= 0;
                if (!beamState.isHorizontal)
                {
                    for (int i = -1; i < 2; i += 2)
                    {
                        if (!spear.room.GetTile(spear.stuckInWall.Value + new Vector2(0f, 20f * (float)i)).Solid)
                        {
                            spear.setRotation = new Vector2?(new Vector2(0f, -1f));
                            break;
                        }
                    }
                    beamState.wasBeam[1] = false;
                    spear.room.GetTile(spear.stuckInWall.Value).verticalBeam = true;
                    for (int i = -1; i < 2; i += 2)
                    {
                        beamState.wasBeam[i + 1] = false;
                        if (!spear.room.GetTile(spear.stuckInWall.Value + new Vector2(0f, 20f * (float)i)).Solid)
                        {
                            spear.room.GetTile(spear.stuckInWall.Value + new Vector2(0f, 20f * (float)i)).verticalBeam = true;
                        }
                    }
                }
                else
                {
                    for (int i = -1; i < 2; i += 2)
                    {
                        if (!spear.room.GetTile(spear.stuckInWall.Value + new Vector2(20f * (float)i, 0f)).Solid)
                        {
                            spear.setRotation = new Vector2?(new Vector2((i >= 0) ? -1f : 1f, 0f));
                            break;
                        }
                    }
                    beamState.wasBeam[1] = false;
                    spear.room.GetTile(spear.stuckInWall.Value).horizontalBeam = true;
                    for (int i = -1; i < 2; i += 2)
                    {
                        beamState.wasBeam[i + 1] = false;
                        if (!spear.room.GetTile(spear.stuckInWall.Value + new Vector2(20f * (float)i, 0f)).Solid)
                        {
                            spear.room.GetTile(spear.stuckInWall.Value + new Vector2(20f * (float)i, 0f)).horizontalBeam = true;
                        }
                    }
                }
            }

            SpearBeamStates.Add(spear.abstractSpear, beamState);
        }

        public static bool HitPatch(On.Spear.orig_HitSomething orig, Spear spear, SharedPhysics.CollisionResult result, bool eu)
        {
            if (!LancerMod.IsPup)
            {
                goto parry;
            }

            if (result.obj is Player)
            { //force kill
                if (LancerMod.config.configMachine && !LancerMod.IsMelee) { goto nonParry; }
                if (spear.thrownBy is Scavenger && PlayerPatch.stats[(result.obj as Player).playerState.playerNumber].fire > 0)
                { // ignore or mimic parry
                    Debug.Log("Scav Parried Lancer!");
                    return false;
                }
            nonParry:
                (result.obj as Creature).Violence(spear.firstChunk, new Vector2?(spear.firstChunk.vel * spear.firstChunk.mass * 2f),
                result.chunk, result.onAppendagePos, Creature.DamageType.Stab, Mathf.Max(spear.spearDamageBonus, 1f), 20f);
            }
        parry:
            if (result.obj is Spear)
            { //Parry
                if (!LancerMod.IsMelee) { return orig.Invoke(spear, result, eu); }
                Spear otherSpear = result.obj as Spear;
                if (SpearBeamStates.TryGetValue(spear.abstractSpear, out BeamState beamState))
                {
                    beamState.used += 4;
                    UpdateBeamState(spear, beamState);
                }
                if (otherSpear.thrownBy is Scavenger)
                {
                    otherSpear.thrownBy.Grab(otherSpear, 0, 0, Creature.Grasp.Shareability.CanOnlyShareWithNonExclusive, 1f, true, true);
                }
            }
            else if (LancerMod.IsMelee && result.obj is Creature)
            {
                Creature crit = result.obj as Creature;
                if (CreaturePatch.MoreHealthStates.TryGetValue((result.obj as Creature).abstractCreature, out CreaturePatch.HealthAddState addState))
                {
                    addState.comboDmg += spear.spearDamageBonus;
                    addState.comboDrain = addState.comboDrain == 0 ? 80 : addState.comboDrain + 25;
                    if (addState.comboDmg > addState.threshhold)
                    {
                        addState.ignoreStun += Math.Min(80, addState.ignoreStun == 0 ? Mathf.CeilToInt(addState.threshhold * 20f) : Mathf.CeilToInt(addState.threshhold * 8f));
                    }
                    //Debug.Log(string.Concat("LancerCrit: ", crit.Template.type, " cDmg: ", addState.comboDmg, " cDr: ", addState.comboDrain));
                    CreaturePatch.MoreHealthStates.Remove(crit.abstractCreature);
                    CreaturePatch.MoreHealthStates.Add(crit.abstractCreature, addState);
                }
            }

            return orig.Invoke(spear, result, eu);
        }

        public static void DrawSprPatch(On.Spear.orig_DrawSprites orig, Spear spear, RoomCamera.SpriteLeaser sLeaser, RoomCamera rCam, float timeStacker, Vector2 camPos)
        {
            orig.Invoke(spear, sLeaser, rCam, timeStacker, camPos);

            if (!sLeaser.sprites[0].isVisible) { return; }
            if (!LancerMod.IsMelee) { return; }
            if (spear.mode != Weapon.Mode.StuckInWall && spear.grabbedBy.Count > 0 && spear.grabbedBy[0].grabber is Player)
            {
                if (PlayerPatch.stats[(spear.grabbedBy[0].grabber as Player).playerState.playerNumber].pull > 0 ||
                    PlayerPatch.stats[(spear.grabbedBy[0].grabber as Player).playerState.playerNumber].polish > 0) { return; }
                Vector2 aimDir = Custom.DirVec(spear.grabbedBy[0].grabber.mainBodyChunk.pos, new Vector2(spear.grabbedBy[0].grabber.mainBodyChunk.pos.x
                    + (float)(spear.grabbedBy[0].grabber as Player).ThrowDirection, spear.grabbedBy[0].grabber.mainBodyChunk.pos.y));
                if (spear is ExplosiveSpear)
                {
                    (spear as ExplosiveSpear).rag[0, 0] = Vector2.Lerp(spear.firstChunk.lastPos, spear.firstChunk.pos, 1f) + aimDir * 15f;
                    (spear as ExplosiveSpear).rag[0, 2] *= 0f;
                    Vector2 tie = Vector2.Lerp((spear as ExplosiveSpear).rag[0, 1], (spear as ExplosiveSpear).rag[0, 0], timeStacker);
                    float vel = 2f * Vector3.Slerp((spear as ExplosiveSpear).rag[0, 4], (spear as ExplosiveSpear).rag[0, 3], timeStacker).x;
                    Vector2 normalized = ((spear as ExplosiveSpear).rag[0, 0] - tie).normalized;
                    Vector2 perp = Custom.PerpendicularVector(normalized);
                    float d = Vector2.Distance((spear as ExplosiveSpear).rag[0, 0], tie) / 5f;
                    (sLeaser.sprites[2] as TriangleMesh).MoveVertice(0, (spear as ExplosiveSpear).rag[0, 0] - normalized * d - perp * vel * 0.5f - camPos);
                    (sLeaser.sprites[2] as TriangleMesh).MoveVertice(1, (spear as ExplosiveSpear).rag[0, 0] - normalized * d + perp * vel * 0.5f - camPos);
                    (sLeaser.sprites[2] as TriangleMesh).MoveVertice(2, tie + normalized * d - perp * vel - camPos);
                    (sLeaser.sprites[2] as TriangleMesh).MoveVertice(3, tie + normalized * d + perp * vel - camPos);
                }
                for (int i = (!(spear is ExplosiveSpear)) ? 0 : 1; i >= 0; i--)
                {
                    sLeaser.sprites[i].rotation = Custom.AimFromOneVectorToAnother(new Vector2(0f, 0f), aimDir);// - 90f;
                }
            }
        }

        public static void ChangeModePatch(On.Spear.orig_ChangeMode orig, Spear spear, Weapon.Mode newMode)
        {
            if (spear.mode == Weapon.Mode.StuckInWall && newMode != Weapon.Mode.StuckInWall)
            {
                spear.abstractSpear.stuckInWallCycles = 0;
                if (!(spear is ExplosiveSpear) && SpearBeamStates.TryGetValue(spear.abstractSpear, out BeamState beamState))
                {
                    if (beamState.hasBeamState)
                    {
                        Vector2 dir = new Vector2();

                        if (beamState.isHorizontal)
                        {
                            spear.room.GetTile(spear.stuckInWall.Value).horizontalBeam = beamState.wasBeam[1];
                            for (int i = -1; i < 2; i += 2)
                            {
                                if (!spear.room.GetTile(spear.stuckInWall.Value + new Vector2(20f * (float)i, 0f)).Solid)
                                { spear.room.GetTile(spear.stuckInWall.Value + new Vector2(20f * (float)i, 0f)).horizontalBeam = beamState.wasBeam[i + 1]; }
                                else
                                { dir = new Vector2(i, 0); }
                            }
                        }
                        else
                        {
                            spear.room.GetTile(spear.stuckInWall.Value).verticalBeam = beamState.wasBeam[1];
                            for (int i = -1; i < 2; i += 2)
                            {
                                if (!spear.room.GetTile(spear.stuckInWall.Value + new Vector2(0f, 20f * (float)i)).Solid)
                                { spear.room.GetTile(spear.stuckInWall.Value + new Vector2(0f, 20f * (float)i)).verticalBeam = beamState.wasBeam[i + 1]; }
                                else
                                { dir = new Vector2(0, i); }
                            }
                        }
                        beamState.hasBeamState = false;

                        if (spear.room != null)
                        {
                            spear.room.PlaySound(SoundID.Spear_Stick_In_Wall, spear.firstChunk.pos, 0.8f, 1.2f);
                            for (int s = Mathf.CeilToInt(UnityEngine.Random.value * 8f); s >= 0; s--)
                            {
                                spear.room.AddObject(new MouseSpark(spear.firstChunk.pos, dir * 12f * UnityEngine.Random.value + UnityEngine.Random.value * 8f * Custom.RNV(), 12f, Color.grey));
                            }
                            //spear.room.AddObject(new ExplosionSpikes(spear.room, spear.firstChunk.pos, 5, 2f, 4f, 4.5f, 30f, new Color(1f, 1f, 1f, 0.5f)));
                        }
                        spear.abstractSpear.stuckInWallCycles = 0;
                        beamState.used += (byte)(LancerMod.IsMelee ? 12 : 0);
                    }
                }
            } // This is temp fix that'll go away when SpearBeamStates behave normally
            orig.Invoke(spear, newMode);
            if (newMode == Weapon.Mode.StuckInWall)
            {
                if (!(spear is ExplosiveSpear) && SpearBeamStates.TryGetValue(spear.abstractSpear, out BeamState beamState))
                {
                    beamState.addPoles = false;
                    if (spear.abstractSpear.stuckInWallCycles < 0) //Mathf.Abs(spear.firstChunk.vel.y) > Mathf.Abs(spear.firstChunk.vel.x * 2f))
                    { //vertical throw
                        beamState.isHorizontal = false;
                        for (int i = -1; i < 2; i += 2)
                        {
                            if (!spear.room.GetTile(spear.stuckInWall.Value + new Vector2(0f, 20f * (float)i)).Solid)
                            {
                                beamState.addPoles = true;
                                spear.setRotation = new Vector2?(new Vector2(0f, -1f));
                                break;
                            }
                        }
                    }
                    else
                    {
                        beamState.isHorizontal = true;
                        for (int i = -1; i < 2; i += 2)
                        {
                            if (!spear.room.GetTile(spear.stuckInWall.Value + new Vector2(20f * (float)i, 0f)).Solid)
                            {
                                beamState.addPoles = true;
                                spear.setRotation = new Vector2?(new Vector2((i >= 0) ? -1f : 1f, 0f));
                                break;
                            }
                        }
                    }
                    UpdateBeamState(spear, beamState);
                }
            }
        }

        public static void UpdatePatch(On.Spear.orig_Update orig, Spear spear, bool eu)
        {
            if (SpearBeamStates.TryGetValue(spear.abstractSpear, out BeamState beamState))
            {
                if (spear.room.readyForAI && beamState.addPoles)
                {
                    // beamState.isHorizontal = spear.abstractSpear.stuckInWallCycles >= 0;
                    if (beamState.isHorizontal)
                    {
                        beamState.wasBeam[1] = spear.room.GetTile(spear.stuckInWall.Value).horizontalBeam;
                        spear.room.GetTile(spear.stuckInWall.Value).horizontalBeam = true;
                        for (int i = -1; i < 2; i += 2)
                        {
                            beamState.wasBeam[i + 1] = spear.room.GetTile(spear.stuckInWall.Value + new Vector2(20f * (float)i, 0f)).horizontalBeam;
                            if (!spear.room.GetTile(spear.stuckInWall.Value + new Vector2(20f * (float)i, 0f)).Solid)
                            { spear.room.GetTile(spear.stuckInWall.Value + new Vector2(20f * (float)i, 0f)).horizontalBeam = true; }
                        }
                    }
                    else
                    {
                        beamState.wasBeam[1] = spear.room.GetTile(spear.stuckInWall.Value).verticalBeam;
                        spear.room.GetTile(spear.stuckInWall.Value).verticalBeam = true;
                        for (int i = -1; i < 2; i += 2)
                        {
                            beamState.wasBeam[i + 1] = spear.room.GetTile(spear.stuckInWall.Value + new Vector2(20f * (float)i, 0f)).verticalBeam;
                            if (!spear.room.GetTile(spear.stuckInWall.Value + new Vector2(0f, 20f * (float)i)).Solid)
                            { spear.room.GetTile(spear.stuckInWall.Value + new Vector2(0f, 20f * (float)i)).verticalBeam = true; }
                        }
                    }
                    beamState.addPoles = false; beamState.hasBeamState = true;
                    // Debug.Log(string.Concat("Lancer Update) ", spear.abstractSpear.ID, " isHorizontal: ", beamState.isHorizontal));
                    UpdateBeamState(spear, beamState);
                    orig.Invoke(spear, eu);
                }
                else if (spear.mode == Weapon.Mode.Thrown && beamState.used > 15)
                { //Disable sticking => replace Update
                    ((Action<bool>)(Activator.CreateInstance(typeof(Action<bool>), spear, typeof(Weapon).GetMethod("Update").MethodHandle.GetFunctionPointer())))(eu);
                    spear.soundLoop.Update();
                }
                else
                { orig.Invoke(spear, eu); }
            }
            else { orig.Invoke(spear, eu); }

            if (!LancerMod.IsMelee) { return; }

            // Fix graphics for melee spear holding
            if (spear.grabbedBy.Count > 0 && spear.grabbedBy[0].grabber is Player)
            {
                Vector2 aimDir = Custom.DirVec(spear.grabbedBy[0].grabber.mainBodyChunk.pos, new Vector2(spear.grabbedBy[0].grabber.mainBodyChunk.pos.x
                        + (float)(spear.grabbedBy[0].grabber as Player).ThrowDirection, spear.grabbedBy[0].grabber.mainBodyChunk.pos.y));

                if (!(spear is ExplosiveSpear) && beamState.used < 6 && spear.room.BeingViewed && UnityEngine.Random.value < 0.04f)
                { //sparkle
                    spear.room.AddObject(new MouseSpark(spear.firstChunk.pos + aimDir * (15f + 5f * UnityEngine.Random.value),
                        Custom.RNV() * UnityEngine.Random.value * 4f, 12f, Color.white));
                }
                if (spear is ExplosiveSpear)
                {
                    (spear as ExplosiveSpear).rag[0, 0] = Vector2.Lerp(spear.firstChunk.lastPos, spear.firstChunk.pos, 1f) + aimDir * 15f;
                    (spear as ExplosiveSpear).rag[0, 2] *= 0f;
                }

                for (int l = spear.abstractPhysicalObject.stuckObjects.Count - 1; l >= 0; l--)
                {
                    if (spear.abstractPhysicalObject.stuckObjects[l] is AbstractPhysicalObject.ImpaledOnSpearStick)
                    {
                        if (spear.abstractPhysicalObject.stuckObjects[l].B.realizedObject != null && (spear.abstractPhysicalObject.stuckObjects[l].B.realizedObject.slatedForDeletetion || spear.abstractPhysicalObject.stuckObjects[l].B.realizedObject.grabbedBy.Count > 0))
                        {
                            spear.abstractPhysicalObject.stuckObjects[l].Deactivate();
                        }
                        else if (spear.abstractPhysicalObject.stuckObjects[l].B.realizedObject != null && spear.abstractPhysicalObject.stuckObjects[l].B.realizedObject.room == spear.room)
                        {
                            spear.abstractPhysicalObject.stuckObjects[l].B.realizedObject.firstChunk.MoveFromOutsideMyUpdate(eu, spear.firstChunk.pos + aimDir * Custom.LerpMap((float)(spear.abstractPhysicalObject.stuckObjects[l] as AbstractPhysicalObject.ImpaledOnSpearStick).onSpearPosition, 0f, 4f, 15f, -15f));
                            spear.abstractPhysicalObject.stuckObjects[l].B.realizedObject.firstChunk.vel *= 0f;
                        }
                    }
                }
            }
        }

        public static void LodgeCreaturePatch(On.Spear.orig_LodgeInCreature orig, Spear spear, SharedPhysics.CollisionResult result, bool eu)
        {
            int slugcat;
            if (spear is ExplosiveSpear || !LancerMod.IsMelee)
            {
                orig.Invoke(spear, result, eu);
                if (spear.thrownBy is Player)
                {
                    slugcat = (spear.thrownBy as Player).playerState.playerNumber;
                    PlayerPatch.stats[slugcat].fire = 0;
                    PlayerPatch.stats[slugcat].firedSpear = null;
                }
                return;
            }
            float oldDmg = spear.spearDamageBonus;
            if (spear.thrownBy is Player)
            {
                slugcat = (spear.thrownBy as Player).playerState.playerNumber;
                if (SpearBeamStates.TryGetValue(spear.abstractSpear, out BeamState beamState))
                {
                    if (beamState.used < 30) { spear.spearDamageBonus = Mathf.Max(1f, spear.spearDamageBonus); }
                    orig.Invoke(spear, result, eu);
                    spear.spearDamageBonus = oldDmg;

                    float chance = Mathf.Pow(Mathf.Clamp01((float)(beamState.used - 8f) / 16f), 2.4f);
                    beamState.used++;
                    if (result.obj is Fly)
                    {
                        //beamState.used--;
                        goto retrieve;
                    }
                    if (beamState.slideThrown)
                    {
                        Creature c = result.obj as Creature;
                        if (CreaturePatch.MoreHealthStates.TryGetValue(c.abstractCreature, out CreaturePatch.HealthAddState state))
                        {
                            state.ignoreStun = 0;
                            CreaturePatch.MoreHealthStates.Remove(c.abstractCreature);
                            CreaturePatch.MoreHealthStates.Add(c.abstractCreature, state);
                        }
                        if (!(c.Template.type == CreatureTemplate.Type.RedCentipede || c.Template.type == CreatureTemplate.Type.RedLizard))
                        { c.Stun(24); }
                        else { c.Stun(10); }
                        if (spear.room.BeingViewed)
                        {
                            if (result.chunk != null)
                            {
                                for (int w = 0; w < 12; w++)
                                {
                                    spear.room.AddObject(new Spark(result.chunk.pos + Custom.DirVec(result.chunk.pos,
                                result.collisionPoint) * result.chunk.rad, Custom.RNV() * UnityEngine.Random.value * 10f, Color.white, null, 40, 120));
                                }
                            }
                            else
                            {
                                for (int w = 0; w < 12; w++)
                                {
                                    spear.room.AddObject(new Spark(spear.firstChunk.pos, Custom.RNV() * UnityEngine.Random.value * 10f, Color.white, null, 40, 120));
                                }
                            }
                        }
                        beamState.used += 3;
                        spear.room.PlaySound(SoundID.Dart_Maggot_Stick_In_Creature, spear.firstChunk.pos, 1.4f, 0.7f);
                        PlayerPatch.stats[slugcat].fire = 0;
                        PlayerPatch.stats[slugcat].firedSpear = null;
                        SpearBeamStates.Remove(spear.abstractSpear);
                        SpearBeamStates.Add(spear.abstractSpear, beamState);
                        return;
                    }
                    UpdateBeamState(spear, beamState);
                    if (UnityEngine.Random.value > chance && PlayerPatch.stats[slugcat].fire != 0)
                    { goto retrieve; }
                }

                // stuck
                if (oldDmg > 0f && spear.room.BeingViewed)
                {
                    spear.room.AddObject(new ExplosionSpikes(spear.room, result.chunk.pos + Custom.DirVec(result.chunk.pos,
                        result.collisionPoint) * result.chunk.rad, 5, 4f, 6f, 4.5f, 30f, new Color(1f, 1f, 1f, 0.5f)));
                    spear.room.PlaySound(SoundID.Spear_Bounce_Off_Creauture_Shell, spear.firstChunk.pos, 1.4f, 0.7f);
                }
                PlayerPatch.stats[slugcat].fire = 0;
                PlayerPatch.stats[slugcat].firedSpear = null;
            }
            else
            {
                spear.spearDamageBonus = Mathf.Max(1f, spear.spearDamageBonus);
                orig.Invoke(spear, result, eu);
            }
            return;

        retrieve:
            (spear.thrownBy as Player).SlugcatGrab(spear, PlayerPatch.stats[slugcat].lanceGrasp);
        }

        public static void PickUpPatch(On.Spear.orig_PickedUp orig, Spear spear, Creature upPicker)
        {
            if (SpearBeamStates.TryGetValue(spear.abstractSpear, out BeamState beamState))
            {
                if (!LancerMod.IsMelee)
                {
                    orig.Invoke(spear, upPicker);
                    return;
                }
                if (spear.lastMode == Weapon.Mode.StuckInCreature && upPicker is Player)
                {
                    if (spear.stuckInObject is PoleMimic || spear.stuckInObject is TentaclePlant)
                    {
                        UpdateBeamState(spear, beamState);
                        orig.Invoke(spear, upPicker);
                        return;
                    }
                    beamState.used = (byte)Mathf.FloorToInt(beamState.used * 0.9f - 1f);
                    int slugcat = (upPicker as Player).playerState.playerNumber;
                    PlayerPatch.stats[slugcat].firedSpear = spear;
                    PlayerPatch.stats[slugcat].pull = (byte)Mathf.FloorToInt(Mathf.Clamp(Mathf.Pow(spear.stuckInChunk.rad * 1.5f, 2.4f) + 16f, 32f, 128f));
                    spear.room.PlaySound(SoundID.Daddy_And_Bro_Tentacle_Grab_Creature, spear.firstChunk.pos, 0.9f, 0.5f);
                    PlayerPatch.stats[slugcat].corpseChunk = spear.stuckInChunk;

                    /* if (spear.room.BeingViewed)
                    {
                        for (int i = 0; i < 8; i++)
                        {
                            spear.room.AddObject(new WaterDrip(spear.firstChunk.pos, Custom.RNV() * UnityEngine.Random.value * 10f, false));
                        }
                    }
                    */
                }
                //Debug.Log(string.Concat("beamState.used: ", beamState.used));
                UpdateBeamState(spear, beamState);
            }

            orig.Invoke(spear, upPicker);
        }
    }
}
