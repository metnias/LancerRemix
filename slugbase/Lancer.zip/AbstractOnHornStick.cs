﻿namespace Lancer
{
    public static partial class PlayerPatch
    {
        public class AbstractOnHornStick : AbstractPhysicalObject.AbstractObjectStick
        {
            public AbstractOnHornStick(AbstractPhysicalObject player, AbstractPhysicalObject mask) : base(player, mask)
            {
            }

            public AbstractPhysicalObject Player
            {
                get { return this.A; }
                set { this.A = value; }
            }

            public AbstractPhysicalObject Mask
            {
                get { return this.B; }
                set { this.B = value; }
            }

            public override string SaveToString(int roomIndex)
            {
                return string.Concat(new string[]
                {
                    roomIndex.ToString(),
                    "<stkA>gripStk<stkA>",
                    this.A.ID.ToString(),
                    "<stkA>",
                    this.B.ID.ToString(),
                    "<stkA>",
                    "2",
                    "<stkA>",
                    "1"
                });
            }
        }
    }
}