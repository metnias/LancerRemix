using RWCustom;
using System.Collections.Generic;
using UnityEngine;

namespace Lancer
{
    public static partial class PlayerPatch
    {
        public static void Patch()
        {
            stats = new LancerState[totalPlayerNum];

            On.SlugcatStats.ctor += new On.SlugcatStats.hook_ctor(StatPatch);
            On.SlugcatStats.SlugcatFoodMeter += new On.SlugcatStats.hook_SlugcatFoodMeter(FoodMeterPatch);
            On.Player.ctor += new On.Player.hook_ctor(CtorPatch);
            On.Player.ObjectEaten += new On.Player.hook_ObjectEaten(ObjectEatPatch);
            On.Player.EatMeatUpdate += new On.Player.hook_EatMeatUpdate(MeatUpdatePatch);
            On.Player.AddFood += new On.Player.hook_AddFood(AddFoodPatch);
            On.HUD.FoodMeter.ctor += new On.HUD.FoodMeter.hook_ctor(FoodMtrCtorPatch);
            On.Player.Update += new On.Player.hook_Update(UpdatePatch);
            On.Player.GraphicsModuleUpdated += new On.Player.hook_GraphicsModuleUpdated(GrafUpdatedPatch);
            On.Player.MovementUpdate += new On.Player.hook_MovementUpdate(MoveUpdatePatch);
            On.Player.LungUpdate += new On.Player.hook_LungUpdate(LungUpdatePatch);
            On.Player.ThrowObject += new On.Player.hook_ThrowObject(ThrowPatch);
            On.Player.Jump += new On.Player.hook_Jump(JumpPatch);
            On.Player.TerrainImpact += new On.Player.hook_TerrainImpact(TerrainImpactPatch);
            On.Player.CanIPickThisUp += new On.Player.hook_CanIPickThisUp(CanIPickUpPatch);
            On.Player.Stun += new On.Player.hook_Stun(StunPatch);
            On.Player.Die += new On.Player.hook_Die(DiePatch);
            On.Player.ThrowToGetFree += new On.Player.hook_ThrowToGetFree(ThrowToGetFreePatch);
        }

        public static LancerState[] stats;

        public static int totalPlayerNum = 4;

        public static void MoreSlugcat(int slugcatNo)
        {
            List<LancerState> bStats = new List<LancerState>();
            for (int b = 0; b < stats.Length; b++)
            { bStats.Add(stats[b]); }
            totalPlayerNum = slugcatNo + 1;
            stats = new LancerState[totalPlayerNum];
            for (int b = 0; b < stats.Length; b++)
            { stats[b] = bStats[b]; }
        }

        public static void StatPatch(On.SlugcatStats.orig_ctor orig, SlugcatStats instance, int slugcatCharacter, bool malnourished)
        {
            orig.Invoke(instance, slugcatCharacter, malnourished);
            if (!LancerMod.IsPup) { return; }
            instance.lungsFac = 0.9f;
            instance.poleClimbSpeedFac = 1.1f;
            instance.corridorClimbSpeedFac = 1.05f;
            instance.runspeedFac = 1.2f;
            instance.bodyWeightFac = 1f;
            instance.generalVisibilityBonus = 0.1f;
            instance.visualStealthInSneakMode = 0.3f;
            switch (instance.name)
            {
                case SlugcatStats.Name.White:
                    instance.throwingSkill = 1;
                    break;

                case SlugcatStats.Name.Yellow:
                    instance.bodyWeightFac = 0.8f;
                    instance.generalVisibilityBonus = 0f;
                    instance.visualStealthInSneakMode = 0.5f;
                    instance.loudnessFac = 0.75f;
                    instance.lungsFac = 1f;
                    instance.throwingSkill = 0;
                    break;

                case SlugcatStats.Name.Red:
                    instance.runspeedFac = 1.4f;
                    instance.bodyWeightFac = 1.12f;
                    instance.generalVisibilityBonus = 0.2f;
                    instance.loudnessFac = 1.35f;
                    instance.throwingSkill = 2;
                    instance.poleClimbSpeedFac = 1.3f;
                    instance.corridorClimbSpeedFac = 1.25f;
                    break;
            }
        }

        public static IntVector2 FoodMeterPatch(On.SlugcatStats.orig_SlugcatFoodMeter orig, int slugcatNum)
        {
            if (slugcatNum == 1) { return new IntVector2(3, 2); }
            return orig.Invoke(slugcatNum);
        }

        public static void CtorPatch(On.Player.orig_ctor orig, Player player, AbstractCreature abstractCreature, World world)
        {
            orig.Invoke(player, abstractCreature, world);
            int playerNum = player.playerState.playerNumber; //instance.playerState.slugcatCharacter;
            if (playerNum >= totalPlayerNum)
            { // exception handler
                Debug.Log("MORE SLUGCAT DETEACTED: " + playerNum.ToString());
                MoreSlugcat(playerNum);
            }

            stats[playerNum] = new LancerState()
            {
                fire = 0,
                firedSpear = null,
                delay = 40,
                pull = 0,
                corpseChunk = null,
                polish = 0,
                polishRock = null,
                polishSpear = null,
                mask = LancerMod.EnableHorn ? new MaskOnHorn(player) : null,
                horn = int.MaxValue,
                hornOverlay = true
            };

            if (!LancerMod.IsPup) { return; }
            float num = 0.5f * player.slugcatStats.bodyWeightFac;
            player.bodyChunks[0] = new BodyChunk(player, 0, new Vector2(0f, 0f), 9f, num / 2f);
            player.bodyChunks[1] = new BodyChunk(player, 1, new Vector2(0f, 0f), 8f, num / 2f);
            player.bodyChunkConnections[0] = new PhysicalObject.BodyChunkConnection(player.bodyChunks[0], player.bodyChunks[1], 12f, PhysicalObject.BodyChunkConnection.Type.Normal, 1f, 0.5f);

            if (player.slugcatStats.name == SlugcatStats.Name.Yellow && player.room.game.session is StoryGameSession && player.room.abstractRoom?.name == "SU_C04")
            { //give first food for monk
                player.playerState.foodInStomach = 1;
            }
        }

        public static bool CanPutMaskOnHorn(Player player)
        {
            int slugcat = player.playerState.playerNumber;
            return !stats[slugcat].mask.HasAMask && (player.grasps[0]?.grabbed is VultureMask || player.grasps[1]?.grabbed is VultureMask);
        }

        public static bool CanRetrieveMaskFromHorn(Player player)
        {
            int slugcat = player.playerState.playerNumber;
            int grasp = -1;
            for (int i = 0; i < 2; i++)
            {
                if (player.grasps[i] == null) { grasp = i; continue; }
                if (player.grasps[i]?.grabbed is IPlayerEdible || player.grasps[i].grabbed is Spear) { return false; }
                if ((int)player.Grabability(player.grasps[i].grabbed) >= 3) { return false; }
            }
            if (player.spearOnBack != null && player.spearOnBack.HasASpear) { return false; }
            return stats[slugcat].mask.HasAMask && grasp > -1;
        }

        public static void FoodMtrCtorPatch(On.HUD.FoodMeter.orig_ctor orig, HUD.FoodMeter instance, HUD.HUD hud, int maxFood, int survivalLimit)
        {
            orig.Invoke(instance, hud, maxFood, survivalLimit);
            if (LancerMod.IsLancer && hud.owner is Player && (hud.owner as Player).slugcatStats.name == SlugcatStats.Name.Yellow)
            { instance.quarterPipShower = new HUD.FoodMeter.QuarterPipShower(instance); }
        }

        public static void ObjectEatPatch(On.Player.orig_ObjectEaten orig, Player player, IPlayerEdible edible)
        {
            stats[player.playerState.playerNumber].eatObj = true;
            if (LancerMod.IsLancer && player.slugcatStats.name == SlugcatStats.Name.Yellow)
            {
                if (player.graphicsModule != null)
                {
                    (player.graphicsModule as PlayerGraphics).LookAtNothing();
                }
                for (int p = 0; p < edible.FoodPoints; p++)
                {
                    player.AddQuarterFood();
                }
            }
            else
            {
                orig.Invoke(player, edible);
            }
            if (stats[player.playerState.playerNumber].mask != null) { stats[player.playerState.playerNumber].mask.interactionLocked = true; }
        }

        public static void MeatUpdatePatch(On.Player.orig_EatMeatUpdate orig, Player player)
        {
            stats[player.playerState.playerNumber].eatObj = false;
            orig.Invoke(player);
        }

        public static void AddFoodPatch(On.Player.orig_AddFood orig, Player player, int add)
        {
            if (!LancerMod.IsLancer || player.slugcatStats.name != SlugcatStats.Name.Yellow) { orig.Invoke(player, add); return; }
            if (stats[player.playerState.playerNumber].eatObj) { orig.Invoke(player, add); }
            else
            {
                for (int p = 0; p < add; p++)
                {
                    if (player.FoodInStomach >= player.MaxFoodInStomach) { return; }
                    player.playerState.quarterFoodPoints++;
                    if (player.playerState.quarterFoodPoints > 3)
                    {
                        player.playerState.quarterFoodPoints -= 4;
                        orig.Invoke(player, 1);
                    }
                }
            }
        }

        public static void UpdatePatch(On.Player.orig_Update orig, Player player, bool eu)
        {
            int slugcat = player.playerState.playerNumber;

            if (stats[slugcat].pull > 0)
            {
                stats[slugcat].pull--;
                player.Blink(5);
                player.bodyChunks[0].vel += Custom.RNV() * UnityEngine.Random.value * 3f + new Vector2(0f, 1f);
                player.bodyChunks[1].vel.x *= 0.3f;
                if (stats[slugcat].pull == 0)
                {
                    player.room.PlaySound(SoundID.Spear_Dislodged_From_Creature, player.bodyChunks[0].pos, 1.3f, 0.7f);
                    stats[slugcat].corpseChunk = null;
                }
                if (stats[slugcat].firedSpear != null && stats[slugcat].corpseChunk != null)
                {
                    player.bodyChunks[0].vel += Custom.DirVec(player.bodyChunks[0].pos, stats[slugcat].corpseChunk.pos) * 0.2f;
                    player.bodyChunks[1].vel += Custom.DirVec(player.bodyChunks[1].pos, stats[slugcat].corpseChunk.pos) * 0.3f;
                    stats[slugcat].corpseChunk.vel *= 0.3f;
                    (stats[slugcat].corpseChunk.owner as Creature).shortcutDelay = 20;

                    player.room.AddObject(new WaterDrip((stats[slugcat].firedSpear.firstChunk.pos + stats[slugcat].corpseChunk.pos) * 0.5f, Custom.RNV() * UnityEngine.Random.value * 10f, false));

                    if ((player.input[0].thrw && !player.input[1].thrw) || player.dangerGrasp != null)
                    { //release; give up pulling
                        stats[slugcat].pull = 0;
                        stats[slugcat].fire = 0; stats[slugcat].delay = 0;
                        stats[slugcat].firedSpear.Thrown(player, player.mainBodyChunk.pos, new Vector2?(player.mainBodyChunk.pos),
                            new IntVector2((player.mainBodyChunk.pos.x >= stats[slugcat].corpseChunk.pos.x) ? -1 : 1, 0), 1f, eu);
                        stats[slugcat].firedSpear.meleeHitChunk = stats[slugcat].corpseChunk;
                        stats[slugcat].firedSpear.spearDamageBonus = 0f;
                        player.ReleaseGrasp(stats[slugcat].firedSpear.grabbedBy[0].graspUsed);
                        stats[slugcat].firedSpear = null;
                    }
                }
            }
            if (!LancerMod.IsMelee) { goto skip; }
            if (player.switchHandsProcess > 0f && stats[slugcat].polish == 0)
            { //init
                if ((player.bodyMode == Player.BodyModeIndex.ClimbingOnBeam && player.animation != Player.AnimationIndex.BeamTip && player.animation != Player.AnimationIndex.StandOnBeam
                    || player.bodyMode == Player.BodyModeIndex.WallClimb)
                    || player.animation == Player.AnimationIndex.AntlerClimb || player.animation == Player.AnimationIndex.VineGrab
                    || player.dangerGrasp != null)
                { goto skip; }
                else if (stats[slugcat].pull != 0) { player.switchHandsProcess = 0f; player.switchHandsCounter = 0; goto skip; }

                bool flagRock = false;
                bool flagSpear = false;
                for (int g = 0; g < player.grasps.Length; g++)
                {
                    if (player.grasps[g] != null)
                    {
                        if (player.grasps[g].grabbed is Rock && !(player.grasps[g].grabbed is WaterNut)) { flagRock = true; stats[slugcat].polishRock = player.grasps[g].grabbed as Rock; }
                        else if (player.grasps[g].grabbed is Spear && !(player.grasps[g].grabbed is ExplosiveSpear))
                        {
                            flagSpear = true; stats[slugcat].polishSpear = player.grasps[g].grabbed as Spear;
                        }
                    }
                }
                if (flagRock && flagSpear)
                {
                    stats[slugcat].polish = Mathf.CeilToInt(UnityEngine.Random.value * 32f + 24f);
                }
                else { stats[slugcat].polishRock = null; stats[slugcat].polishSpear = null; }
            }
        skip:
            orig.Invoke(player, eu);
            if (player.dangerGrasp != null) { if (stats[slugcat].postponeDeath && player.dangerGraspTime >= 60) { stats[slugcat].postponeDeath = false; player.Die(); } }
            else { stats[slugcat].postponeDeath = false; }
            if (stats[slugcat].delay < 40 || (!player.lungsExhausted && UnityEngine.Random.value < 0.2f)) { stats[slugcat].delay++; }
            /*if (player.Stunned)
            {
                fire[slugcat] = 0;
                stats[slugcat].firedSpear = null;
            }*/
            if (!LancerMod.EnableHorn) { return; }
            if (stats[slugcat].mask == null) { stats[slugcat].mask = new MaskOnHorn(player); }
            if (player.input[0].pckp && !stats[slugcat].mask.interactionLocked && (CanPutMaskOnHorn(player) || CanRetrieveMaskFromHorn(player)))
            {
                stats[slugcat].mask.increment = true;
            }
            else { stats[slugcat].mask.increment = false; }
            if (player.input[0].pckp && player.grasps[0] != null && player.grasps[0].grabbed is Creature
                && player.CanEatMeat(player.grasps[0].grabbed as Creature) && (player.grasps[0].grabbed as Creature).Template.meatPoints > 0)
            {
                stats[slugcat].mask.increment = false;
                stats[slugcat].mask.interactionLocked = true;
            }
            else if (player.swallowAndRegurgitateCounter > 90)
            {
                stats[slugcat].mask.increment = false;
                stats[slugcat].mask.interactionLocked = true;
            }
            stats[slugcat].mask.Update(eu);
        }

        public static void StunPatch(On.Player.orig_Stun orig, Player player, int st)
        {
            orig.Invoke(player, st);
            int slugcat = player.playerState.playerNumber;
            if (stats[slugcat].mask != null && stats[slugcat].mask.HasAMask && st > UnityEngine.Random.Range(40, 80))
            { stats[slugcat].mask.DropMask(); }
            if (stats[slugcat].pull > 0)
            { //cancel motion
                stats[slugcat].pull = 0;
                stats[slugcat].fire = 0; stats[slugcat].delay = 0;
                stats[slugcat].firedSpear.Thrown(player, player.mainBodyChunk.pos, new Vector2?(player.mainBodyChunk.pos),
                    new IntVector2((player.mainBodyChunk.pos.x >= stats[slugcat].corpseChunk.pos.x) ? -1 : 1, 0), 1f, true);
                stats[slugcat].firedSpear.meleeHitChunk = stats[slugcat].corpseChunk;
                stats[slugcat].firedSpear.spearDamageBonus = 0f;
                player.ReleaseGrasp(stats[slugcat].firedSpear.grabbedBy[0].graspUsed);
                stats[slugcat].firedSpear = null;
            }
            if (stats[slugcat].polish > 0)
            {
                stats[slugcat].polish = 0;
                player.switchHandsProcess = 0f;
                stats[slugcat].polishRock = null; stats[slugcat].polishSpear = null;
            }
            stats[slugcat].fire = 0; stats[slugcat].delay = 0;
            if (stats[slugcat].firedSpear != null)
            {
                stats[slugcat].firedSpear.firstChunk.vel *= 0;
                stats[slugcat].firedSpear = null;
            }
            stats[slugcat].corpseChunk = null;
            stats[slugcat].polish = 0; stats[slugcat].polishRock = null; stats[slugcat].polishSpear = null;
        }

        public static void GrafUpdatedPatch(On.Player.orig_GraphicsModuleUpdated orig, Player player, bool actuallyViewed, bool eu)
        {
            if (stats[player.playerState.playerNumber].mask != null)
            { stats[player.playerState.playerNumber].mask.GraphicsModuleUpdated(actuallyViewed, eu); }
            orig.Invoke(player, actuallyViewed, eu);
        }

        public static void LungUpdatePatch(On.Player.orig_LungUpdate orig, Player player)
        {
            bool oldExt = player.lungsExhausted;
            orig.Invoke(player);
            if (oldExt && !player.lungsExhausted)
            { player.aerobicLevel -= 0.3f; }
        }

        public static void MoveUpdatePatch(On.Player.orig_MovementUpdate orig, Player player, bool eu)
        {
            int slugcat = player.playerState.playerNumber;
            if (stats[slugcat].pull > 0) { player.animation = Player.AnimationIndex.None; goto polishStun; }
            if (stats[slugcat].polish > 0)
            {
                player.shortcutDelay = 20;
                stats[slugcat].polish--;
                player.switchHandsProcess = Mathf.Sin(stats[slugcat].polish / 3.6f) * 0.6f + 0.2f;
                if (stats[slugcat].polish % 9 == 1)
                {
                    for (int w = 0; w < 8; w++)
                    {
                        player.room.AddObject(new Spark(stats[slugcat].polishSpear.firstChunk.pos, Custom.RNV() * UnityEngine.Random.value * 15f, Color.white, null, 30, 80));
                    }
                    player.room.PlaySound(SoundID.Spear_Bounce_Off_Wall, stats[slugcat].polishSpear.firstChunk.pos, 0.7f, 1.7f);
                    player.room.InGameNoise(new Noise.InGameNoise(player.bodyChunks[1].pos, 250f, player, 4f));
                }
                if ((!(player.grasps[0]?.grabbed is Rock) && !(player.grasps[1]?.grabbed is Rock)) || player.dangerGrasp != null)
                {
                    stats[slugcat].polish = 0;
                    player.switchHandsProcess = 0f;
                }

                if (stats[slugcat].polish == 0)
                {
                    if (SpearPatch.SpearBeamStates.TryGetValue(stats[slugcat].polishSpear.abstractSpear, out SpearPatch.BeamState beamState))
                    { //polish spear
                        beamState.used /= 3;
                        player.room.PlaySound(SoundID.Spear_Bounce_Off_Creauture_Shell, stats[slugcat].polishSpear.firstChunk.pos, 1.1f, 1.2f);
                        SpearPatch.UpdateBeamState(stats[slugcat].polishSpear, beamState);
                    }
                    bool rock = false;
                    if (player.room?.game.IsStorySession == true && UnityEngine.Random.value > 0.3f)
                    { //destroy rock
                        stats[slugcat].polishRock.Destroy();
                        player.room.AddObject(new ExplosionSpikes(player.room, stats[slugcat].polishRock.firstChunk.pos, 5, 2f, 4f, 4.5f, 30f, new Color(1f, 1f, 1f, 0.5f)));
                        player.room.PlaySound(SoundID.Rock_Bounce_Off_Creature_Shell, stats[slugcat].polishRock.firstChunk.pos, 1.3f, 0.6f);
                    }
                    else { rock = true; }
                    player.switchHandsProcess = 0f;
                    if (player.grasps[0]?.grabbed == stats[slugcat].polishSpear)
                    { //revert switch
                        player.ReleaseGrasp(0);
                        player.SlugcatGrab(stats[slugcat].polishSpear, 1);
                        if (rock) { player.SlugcatGrab(stats[slugcat].polishRock, 0); }
                    }
                    else
                    {
                        player.ReleaseGrasp(1);
                        player.SlugcatGrab(stats[slugcat].polishSpear, 0);
                        if (rock) { player.SlugcatGrab(stats[slugcat].polishRock, 1); }
                    }
                }

                switch (player.bodyMode)
                {
                    case Player.BodyModeIndex.Crawl:
                        player.bodyChunks[0].vel.x *= 0.5f; player.surfaceFriction = 0.5f; goto polishStun;
                    case Player.BodyModeIndex.CorridorClimb:
                    case Player.BodyModeIndex.ClimbIntoShortCut:
                    case Player.BodyModeIndex.WallClimb:
                        player.surfaceFriction = 0.9f; goto polishStun;
                    case Player.BodyModeIndex.ClimbingOnBeam:
                        if (player.animation != Player.AnimationIndex.BeamTip && player.animation != Player.AnimationIndex.StandOnBeam)
                        { player.animation = Player.AnimationIndex.None; goto polishStun; }
                        else { break; }
                    default:
                        if (player.animation == Player.AnimationIndex.AntlerClimb || player.animation == Player.AnimationIndex.VineGrab) { goto polishStun; }
                        break;
                }
            }
            orig.Invoke(player, eu);

            if (stats[slugcat].fire > 0)
            {
                stats[slugcat].fire--;
                if (stats[slugcat].fire == 0
                    && (stats[slugcat].firedSpear.mode == Weapon.Mode.Thrown || stats[slugcat].firedSpear.mode == Weapon.Mode.Free))
                { //retrieve
                    player.SlugcatGrab(stats[slugcat].firedSpear, stats[slugcat].lanceGrasp);
                }
            }

            if (!LancerMod.IsPup) { return; }
            if (player.rollDirection != 0)
            {
                player.bodyChunkConnections[0].distance = 7f; //10f
            }
            else
            {
                player.bodyChunkConnections[0].distance = 12f; //17f
            }

            return;
        polishStun:
            player.UpdateAnimation();
            player.UpdateBodyMode();
            player.GrabUpdate(eu);
        }

        public static float GetLanceDamage(Player player)
        {
            if (LancerMod.IsPup)
            {
                switch (player.slugcatStats.name)
                {
                    default:
                    case SlugcatStats.Name.White:
                        return 0.8f + 0.3f * Mathf.Pow(UnityEngine.Random.value, 3f);

                    case SlugcatStats.Name.Yellow:
                        return 0.6f + 0.4f * Mathf.Pow(UnityEngine.Random.value, 4f);

                    case SlugcatStats.Name.Red:
                        return 0.9f + 0.4f * Mathf.Pow(UnityEngine.Random.value, 3f);
                }
            }
            else
            {
                switch (player.slugcatStats.name)
                {
                    default:
                    case SlugcatStats.Name.White:
                        return 0.3f + 0.2f * Mathf.Pow(UnityEngine.Random.value, 3f);

                    case SlugcatStats.Name.Yellow:
                        return 0.2f + 0.3f * Mathf.Pow(UnityEngine.Random.value, 4f);

                    case SlugcatStats.Name.Red:
                        return 0.4f + 0.3f * Mathf.Pow(UnityEngine.Random.value, 3f);
                }
            }
        }

        public static void ThrowPatch(On.Player.orig_ThrowObject orig, Player player, int grasp, bool eu)
        {
            if (!LancerMod.IsMelee)
            {
                orig.Invoke(player, grasp, eu);
                return;
            }
            //delay check
            int slugcat = player.playerState.playerNumber;
            int exhaust = Mathf.CeilToInt(ConstDelay(slugcat) * Mathf.Clamp(Mathf.Pow(Mathf.Clamp(player.aerobicLevel * 2f, 1f, 2f), 1.5f), 1f, 2.5f));
            //Debug.Log(instance.aerobicLevel.ToString() + ": " + exhaust.ToString());
            if (player.grasps[grasp]?.grabbed is Spear && stats[slugcat].delay < exhaust ||
                stats[slugcat].firedSpear == null && stats[slugcat].delay < 30) { return; }

            /*  //arena behavior
            if (instance.room.game.IsArenaSession && instance.grasps[grasp]?.grabbed is Spear)
            {
                Spear spearArena = instance.grasps[grasp].grabbed as Spear;
                if (SpearPatch.SpearBeamState.TryGetValue(spearArena, out SpearPatch.BeamState beamState0))
                {
                    if (beamState0.used < 8)
                    {
                        beamState0.used += 8;
                        SpearPatch.UpdateBeamState(spearArena, beamState0);
                        orig.Invoke(instance, grasp, eu);
                        return;
                    }
                }
                if (spearArena is ExplosiveSpear)
                {
                    orig.Invoke(instance, grasp, eu); return;
                }
            }
            */
            bool flagRock = false; int rock = -1; bool flagSpear = false;
            for (int g = 0; g < player.grasps.Length; g++)
            {
                if (player.grasps[g] != null)
                {
                    if (player.grasps[g]?.grabbed is Rock) { flagRock = true; rock = g; }
                    else if (player.grasps[g]?.grabbed is Spear) { flagSpear = true; }
                }
            }
            if (flagRock && flagSpear)
            { //throw rock instead
                orig.Invoke(player, rock, eu);
                return;
            }
            if (player.grasps[grasp]?.grabbed is Spear)
            {
                goto lance;
            }
            orig.Invoke(player, grasp, eu);
            return;
        lance:
            Spear spear = player.grasps[grasp].grabbed as Spear;
            bool dull = false;
            if (SpearPatch.SpearBeamStates.TryGetValue(spear.abstractSpear, out SpearPatch.BeamState bs))
            { dull = bs.used > 15; }
            stats[slugcat].lanceGrasp = (byte)grasp;
            IntVector2 throwDir = new IntVector2(player.ThrowDirection, 0);
            stats[slugcat].fire = 4;
            if (player.animation == Player.AnimationIndex.Flip && player.input[0].y < 0 && player.input[0].x == 0)
            {
                throwDir = new IntVector2(0, -1);
                stats[slugcat].fire = 6;
            }
            Vector2 thrownPos = player.firstChunk.pos + throwDir.ToVector2() * 5f + new Vector2(0f, 4f);
            if (player.room.GetTile(thrownPos).Solid)
            {
                thrownPos = player.mainBodyChunk.pos;
            }
            //throw to wall
            /*
            if (instance.room.GetTile(instance.bodyChunks[0].pos + throwDir.ToVector2() * 30f).Solid)
            {
                goto lanceInit;
            }*/
            //throw to creature
            if (player.graphicsModule != null)
            {
                for (int i = 0; i < player.room.abstractRoom.creatures.Count; i++)
                {
                    if (player.room.abstractRoom.creatures[i].realizedCreature != null
                        && Custom.DistLess(player.firstChunk.pos, player.room.abstractRoom.creatures[i].realizedCreature.mainBodyChunk.pos, 200f)
                        && player != player.room.abstractRoom.creatures[i].realizedCreature)
                    {
                        Creature candidate = player.room.abstractRoom.creatures[i].realizedCreature;
                        for (int j = 0; j < candidate.bodyChunks.Length; j++)
                        {
                            if (Custom.DistLess(player.firstChunk.pos, candidate.bodyChunks[j].pos, 30f))
                            {
                                //goto lanceInit;
                                (player.graphicsModule as PlayerGraphics).LookAtObject(candidate);
                                goto lanceInit;
                            }
                        }
                    }
                }
            }

        lanceInit:
            player.AerobicIncrease(0.5f);
            if (player.slugcatStats.name == SlugcatStats.Name.Yellow && player.aerobicLevel > 0.9f) //fix this!
            {
                if (player.lungsExhausted) { player.airInLungs -= 0.4f; }
                else
                {
                    player.lungsExhausted = true;
                    player.airInLungs -= 0.3f;
                }
            }
            stats[slugcat].firedSpear = spear;
            spear.spearDamageBonus = GetLanceDamage(player);

            bool slide = false;
            if (!dull && player.animation == Player.AnimationIndex.BellySlide && player.rollCounter > 8 && player.rollCounter < 15)
            { // slide
                if (throwDir.x == player.rollDirection && player.slugcatStats.throwingSkill > 0)
                { //forward
                    spear.firstChunk.vel.x = spear.firstChunk.vel.x + (float)throwDir.x * 15f;
                    spear.floorBounceFrames = 30;
                    spear.alwaysStickInWalls = true;
                    spear.firstChunk.goThroughFloors = false;
                    spear.firstChunk.vel.y = spear.firstChunk.vel.y + 5f;
                    spear.changeDirCounter = 0;
                    player.rollCounter = 8;
                    player.mainBodyChunk.pos.x = player.mainBodyChunk.pos.x + (float)player.rollDirection * 6f;
                    //instance.room.AddObject(new ExplosionSpikes(instance.room, instance.bodyChunks[1].pos + new Vector2((float)instance.rollDirection * -40f, 0f), 6, 5.5f, 4f, 4.5f, 21f, new Color(1f, 1f, 1f, 0.25f)));
                    player.bodyChunks[1].pos.x = player.bodyChunks[1].pos.x + (float)player.rollDirection * 6f;
                    player.bodyChunks[1].pos.y = player.bodyChunks[1].pos.y + 17f;
                    player.mainBodyChunk.vel.x = player.mainBodyChunk.vel.x + (float)player.rollDirection * 16f;
                    player.bodyChunks[1].vel.x = player.bodyChunks[1].vel.x + (float)player.rollDirection * 16f;
                    //instance.room.PlaySound(SoundID.Slugcat_Belly_Slide_Init, instance.mainBodyChunk, false, 1f, 1f);
                    player.exitBellySlideCounter = 0;
                    player.longBellySlide = true;
                    spear.spearDamageBonus *= 1.8f;
                    slide = true;
                }
                else if (throwDir.x == -player.rollDirection && !player.longBellySlide)
                { //reverse
                    throwDir = new IntVector2(0, -1);
                    spear.alwaysStickInWalls = true;
                    spear.firstChunk.goThroughFloors = false;
                    spear.firstChunk.pos.y = spear.firstChunk.pos.y + 5f;
                    spear.changeDirCounter = 0;
                    player.room.AddObject(new ExplosionSpikes(player.room, player.bodyChunks[1].pos + new Vector2((float)player.rollDirection * -40f, 0f), 6, 5.5f, 4f, 4.5f, 21f, new Color(1f, 1f, 1f, 0.25f)));
                    float pow = Mathf.Lerp(1f, 1.5f, player.Adrenaline);
                    player.bodyChunks[1].pos += new Vector2(5f * (float)player.rollDirection, 5f);
                    player.bodyChunks[0].pos = player.bodyChunks[1].pos + new Vector2(5f * (float)player.rollDirection, 5f);
                    player.bodyChunks[1].vel = new Vector2((float)player.rollDirection * 6f, 15f) * pow * ((!player.longBellySlide) ? 1f : 1.5f);
                    player.bodyChunks[0].vel = new Vector2((float)player.rollDirection * 6f, 15f) * pow * ((!player.longBellySlide) ? 1f : 1.5f);
                    player.animation = Player.AnimationIndex.RocketJump;
                    player.rocketJumpFromBellySlide = true;
                    player.room.PlaySound(SoundID.Slugcat_Rocket_Jump, player.mainBodyChunk, false, 1f, 1f);
                    player.rollDirection = 0;
                    //typeof(Player).GetField("exitBellySlideCounter", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance).SetValue(instance, 0);
                    player.AerobicIncrease(0.6f);
                }
            }
            if (SpearPatch.SpearBeamStates.TryGetValue(spear.abstractSpear, out SpearPatch.BeamState beamState))
            {
                if (beamState.used < 6) { spear.spearDamageBonus *= 1.5f; }
                if (beamState.slideThrown != slide)
                {
                    beamState.slideThrown = slide;
                    SpearPatch.UpdateBeamState(spear, beamState);
                }
            }
            spear.Thrown(player, thrownPos, new Vector2?(player.mainBodyChunk.pos - throwDir.ToVector2() * 5f),
                throwDir, Mathf.Lerp(1f, 1.5f, player.Adrenaline), eu);
            spear.firstChunk.vel.x = spear.firstChunk.vel.x * 0.85f;
            player.Blink(5);
            if (player.graphicsModule != null)
            {
                (player.graphicsModule as PlayerGraphics).ThrowObject(grasp, spear);
            }
            spear.Forbid();
            player.ReleaseGrasp(grasp);
            stats[slugcat].delay = 0;
            player.dontGrabStuff = 10;
            player.bodyChunks[0].vel += throwDir.ToVector2() * 4f;
            player.bodyChunks[1].vel -= throwDir.ToVector2() * 3f;
        }

        public static void ThrowToGetFreePatch(On.Player.orig_ThrowToGetFree orig, Player player, bool eu)
        {
            if (!LancerMod.IsMelee || player.dangerGrasp == null) { orig.Invoke(player, eu); return; }
            int num;
            for (int i = 0; i < player.grasps.Length; i++)
            {
                if (player.grasps[i] != null && (player.grasps[i].grabbed is Spear || player.grasps[i].grabbed is Rock))
                { num = i; goto stabToGetFree; }
            }
            orig.Invoke(player, eu);
            return;
        stabToGetFree:
            BodyChunk bodyChunk = null;
            float dst = float.MaxValue;
            for (int l = 0; l < player.dangerGrasp.grabber.bodyChunks.Length; l++)
            {
                if (Custom.DistLess(player.mainBodyChunk.pos, player.dangerGrasp.grabber.bodyChunks[l].pos, dst))
                {
                    bodyChunk = player.dangerGrasp.grabber.bodyChunks[l];
                    dst = Vector2.Distance(player.mainBodyChunk.pos, player.dangerGrasp.grabber.bodyChunks[l].pos);
                }
            }
            if (bodyChunk == null) { return; }
            Weapon w = player.grasps[num].grabbed as Weapon;
            int slugcat = player.playerState.playerNumber;
            //if (w is Spear && !(w is ExplosiveSpear))
            //{ stats[slugcat].fire = 4; stats[slugcat].firedSpear = w as Spear; }
            //else
            //{  }
            stats[slugcat].fire = 0; stats[slugcat].firedSpear = null;
            // if (w is Spear s) { s.spearDamageBonus = Mathf.Max(GetLanceDamage(player) * 2.4f, 1.0f); }
            w.Thrown(player, player.mainBodyChunk.pos, new Vector2?(player.mainBodyChunk.pos),
                new IntVector2((player.mainBodyChunk.pos.x >= bodyChunk.pos.x) ? -1 : 1, 0), 1f, eu);
            w.meleeHitChunk = bodyChunk;
            player.ReleaseGrasp(num);
            stats[slugcat].delay = 0;
        }

        public static void JumpPatch(On.Player.orig_Jump orig, Player player)
        {
            float aerobic = player.aerobicLevel;
            orig.Invoke(player);
            player.aerobicLevel = aerobic;
            player.AerobicIncrease(0.8f);
        }

        public static bool CanIPickUpPatch(On.Player.orig_CanIPickThisUp orig, Player instance, PhysicalObject obj)
        {
            if (obj is Spear)
            {
                if (stats[instance.playerState.playerNumber].fire > 0) { return false; }
                if (!LancerMod.config.disabled && LancerMod.config.spearGrability) { goto skipCheck; }
                if (!instance.CanPutSpearToBack && (instance.grasps[0]?.grabbed is Spear || instance.grasps[1]?.grabbed is Spear))
                {
                    return false;
                }
            skipCheck:
                if ((obj as Spear).mode == Weapon.Mode.StuckInCreature)
                {
                    if (instance.input[0].y <= 0)
                    {
                        if (LancerMod.config.configMachine && !LancerMod.config.melee) { return true; }
                        else { return false; }
                    }
                    if ((obj as Spear).stuckInObject is Creature && stats[instance.playerState.playerNumber].pull == 0 && instance.standing) // && ((obj as Spear).stuckInObject as Creature).dead
                    {
                        if (LancerMod.config.configMachine && LancerMod.config.spearGrability) { return true; }
                        if (instance.grasps[0]?.grabbed is Spear || instance.grasps[1]?.grabbed is Spear) { return false; }
                        return true;
                    }
                    return false;
                }
                else if ((obj as Spear).mode == Weapon.Mode.StuckInWall)
                {
                    if (!LancerMod.config.disabled && !LancerMod.config.canPullSpear) { return false; }
                    if (instance.bodyMode != Player.BodyModeIndex.ClimbingOnBeam && instance.bodyChunks[1].vel.y <= 0f && instance.standing) { return true; }
                    if (instance.bodyMode == Player.BodyModeIndex.ClimbingOnBeam && instance.animation == Player.AnimationIndex.HangFromBeam) { return true; }
                    else { return false; }
                }
                if (LancerMod.config.configMachine && LancerMod.config.spearGrability && (obj as Spear).mode == Weapon.Mode.Free)
                {
                    return true;
                }
            }
            return orig.Invoke(instance, obj);
        }

        public static int ConstDelay(int slugcat)
        {
            int result;
            switch (slugcat)
            {
                case 0:
                case 3:
                    result = 12; break;
                case 1:
                    result = 8; break;
                default:
                case 2:
                    result = 10; break;
            }
            if (!LancerMod.IsPup) { result = Mathf.CeilToInt(result * 1.5f); }
            return result;
        }

        public static void TerrainImpactPatch(On.Player.orig_TerrainImpact orig, Player instance, int chunk, IntVector2 direction, float speed, bool firstContact)
        {
            if (!LancerMod.IsPup)
            {
                orig.Invoke(instance, chunk, direction, speed, firstContact);
                return;
            }
            if (speed > 9f)
            {
                instance.Blink(Custom.IntClamp((int)speed, 9, 60) / 2);
            }
            if (instance.input[0].downDiagonal != 0 && instance.animation != Player.AnimationIndex.Roll
                && ((speed > 9f && speed < 12f) || instance.animation == Player.AnimationIndex.Flip ||
                (instance.animation == Player.AnimationIndex.RocketJump && instance.rocketJumpFromBellySlide))
                && direction.y < 0 && instance.allowRoll > 0 && instance.consistentDownDiagonal > ((speed <= 24f) ? 6 : 1))
            { //roll easier
                if (instance.animation == Player.AnimationIndex.RocketJump && instance.rocketJumpFromBellySlide)
                {
                    instance.bodyChunks[1].vel.y += 3f;
                    instance.bodyChunks[1].pos.y += 3f;
                    instance.bodyChunks[0].vel.y -= 3f;
                    instance.bodyChunks[0].pos.y -= 3f;
                }
                instance.room.PlaySound(SoundID.Slugcat_Roll_Init, instance.mainBodyChunk.pos, 1f, 1f);
                instance.animation = Player.AnimationIndex.Roll;
                instance.rollDirection = instance.input[0].downDiagonal;
                instance.rollCounter = 0;
                instance.bodyChunks[0].vel.x = Mathf.Lerp(instance.bodyChunks[0].vel.x, 9f * (float)instance.input[0].x, 0.7f);
                instance.bodyChunks[1].vel.x = Mathf.Lerp(instance.bodyChunks[1].vel.x, 9f * (float)instance.input[0].x, 0.7f);
                instance.standing = false;
            }
            else if (firstContact)
            {
                if (speed > 40f && speed <= 60f && direction.y < 0)
                {
                    instance.room.PlaySound(SoundID.Slugcat_Terrain_Impact_Death, instance.mainBodyChunk);
                    Debug.Log("Fall damage death");
                    instance.Die();
                }
                else if (speed > 28f && speed <= 40f)
                {
                    instance.room.PlaySound(SoundID.Slugcat_Terrain_Impact_Hard, instance.mainBodyChunk);
                    instance.Stun((int)Custom.LerpMap(speed, 28f, 40f, 40f, 140f, 2.5f));
                }
            }
            orig.Invoke(instance, chunk, direction, speed, firstContact);
        }

        public static void DiePatch(On.Player.orig_Die orig, Player player)
        {
            int slugcat = player.playerState.playerNumber;
            if (stats[slugcat].pull > 0)
            { //cancel motion
                stats[slugcat].pull = 0;
                stats[slugcat].fire = 0; stats[slugcat].delay = 0;
                stats[slugcat].firedSpear.Thrown(player, player.mainBodyChunk.pos, new Vector2?(player.mainBodyChunk.pos),
                    new IntVector2((player.mainBodyChunk.pos.x >= stats[slugcat].corpseChunk.pos.x) ? -1 : 1, 0), 1f, true);
                stats[slugcat].firedSpear.meleeHitChunk = stats[slugcat].corpseChunk;
                stats[slugcat].firedSpear.spearDamageBonus = 0f;
                player.ReleaseGrasp(stats[slugcat].firedSpear.grabbedBy[0].graspUsed);
                stats[slugcat].firedSpear = null;
            }
            stats[slugcat].fire = 0; stats[slugcat].delay = 0;
            if (stats[slugcat].firedSpear != null)
            {
                stats[slugcat].firedSpear.firstChunk.vel *= 0;
                stats[slugcat].firedSpear = null;
            }
            stats[slugcat].corpseChunk = null;
            if (stats[slugcat].polish > 0)
            {
                stats[slugcat].polish = 0;
                player.switchHandsProcess = 0f;
                stats[slugcat].polishRock = null; stats[slugcat].polishSpear = null;
            }

            /* if (LancerMod.config.configMachine && !LancerMod.config.isPup && !LancerMod.config.grape) { orig.Invoke(player); return; }
            if (player.bodyChunks[0].pos.y < -player.bodyChunks[0].restrictInRoomRange && !player.room.water)
            { //bandicoot death
                Debug.Log("Bandicoot Death!");
                if (player.spearOnBack != null && player.spearOnBack.HasASpear)
                {
                    Spear backSpear = player.spearOnBack.spear;
                    player.spearOnBack.DropSpear();
                    backSpear.firstChunk.pos.y -= 400f;
                    backSpear.firstChunk.vel.y = -100f - UnityEngine.Random.value * 10f;
                    backSpear.firstChunk.vel.x = -5f + UnityEngine.Random.value * 10f;
                    backSpear.SetRandomSpin();
                }
                for (int i = 0; i < player.grasps.Length; i++)
                {
                    if (player.grasps[i] != null && player.grasps[i].grabbed != null)
                    {
                        if (player.grasps[i].grabbed is Weapon)
                        {
                            Weapon weapon = player.grasps[i].grabbed as Weapon;
                            player.ReleaseGrasp(i);
                            for (int j = 0; j < weapon.bodyChunks.Length; j++)
                            {
                                weapon.bodyChunks[j].pos.y += 400f;
                                weapon.bodyChunks[j].vel.y = +200f + UnityEngine.Random.value * 10f;
                                weapon.bodyChunks[j].vel.x = -5f + UnityEngine.Random.value * 10f;
                            }
                            weapon.SetRandomSpin();
                        }
                        else
                        {
                            PhysicalObject obj = player.grasps[i].grabbed;
                            player.ReleaseGrasp(i);
                            for (int k = 0; k < obj.bodyChunks.Length; k++)
                            {
                                obj.bodyChunks[k].pos.y += 200f;
                                obj.bodyChunks[k].vel.y = +20f + UnityEngine.Random.value * 10f;
                                obj.bodyChunks[k].vel.x = -5f + UnityEngine.Random.value * 10f;
                            }
                        }
                        Debug.Log(player.grasps[i].grabbed.abstractPhysicalObject?.type);
                        Debug.Log(player.grasps[i].grabbed.firstChunk.vel);
                        Debug.Log(player.grasps[i].grabbed.firstChunk.pos);
                    }
                }
            }*/
            if (player.dangerGrasp != null && !player.dead && player.dangerGraspTime < 60 &&
                !player.dangerGrasp.grabber.abstractCreature.InDen && !player.slatedForDeletetion && !player.dangerGrasp.grabber.slatedForDeletetion)
            {
                Debug.Log(string.Concat("Lancer PostponedDeath! ", player.dangerGrasp.grabber.Template.name, " graspTime: ", player.dangerGraspTime));
                player.LoseAllGrasps(); stats[slugcat].postponeDeath = true;
                return;
            }
            if (stats[slugcat].mask != null && stats[slugcat].mask.HasAMask)
            { stats[slugcat].mask.DropMask(); }
            orig.Invoke(player);
        }
    }
}