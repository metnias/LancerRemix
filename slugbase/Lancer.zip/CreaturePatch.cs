﻿using RWCustom;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace Lancer
{
    public static partial class CreaturePatch
    {
        public static void Patch()
        {
            On.AbstractCreature.ctor += new On.AbstractCreature.hook_ctor(AbstractCtorPatch);
            On.Creature.Update += new On.Creature.hook_Update(UpdatePatch);
            On.Creature.Violence += new On.Creature.hook_Violence(ViolencePatch);
            On.Lizard.Violence += new On.Lizard.hook_Violence(LizViolencePatch);
            On.Creature.Stun += new On.Creature.hook_Stun(StunPatch);
            On.CreatureCommunities.LoadDefaultCommunityAlignments += new On.CreatureCommunities.hook_LoadDefaultCommunityAlignments(LoadDefaultCommunity);

            MoreHealthStates = new Dictionary<AbstractCreature, HealthAddState>();
        }

        public static Dictionary<AbstractCreature, HealthAddState> MoreHealthStates;

        public static void AbstractCtorPatch(On.AbstractCreature.orig_ctor orig, AbstractCreature self, World world, CreatureTemplate creatureTemplate, Creature realizedCreature, WorldCoordinate pos, EntityID ID)
        {
            if (LancerMod.IsMelee)
            {
                // Modify Creature Health
                switch (creatureTemplate.TopAncestor().type)
                {
                    case CreatureTemplate.Type.DropBug:
                        creatureTemplate.baseDamageResistance = 0.6f; break;
                    case CreatureTemplate.Type.SmallNeedleWorm:
                        creatureTemplate.baseDamageResistance = 0.3f; break;
                    case CreatureTemplate.Type.EggBug:
                        creatureTemplate.baseDamageResistance = 0.5f; break;
                    case CreatureTemplate.Type.JetFish:
                        creatureTemplate.baseDamageResistance = 0.6f; break;
                    case CreatureTemplate.Type.CicadaA:
                    case CreatureTemplate.Type.CicadaB:
                        creatureTemplate.baseDamageResistance = 0.6f; break;
                    case CreatureTemplate.Type.SmallCentipede:
                        creatureTemplate.baseDamageResistance = 0.4f; break;
                    case CreatureTemplate.Type.LizardTemplate:
                        creatureTemplate.baseDamageResistance = creatureTemplate.baseDamageResistance < 2f ?
                            creatureTemplate.baseDamageResistance * 1.2f : Mathf.Lerp(creatureTemplate.baseDamageResistance, 20f, 0.1f);
                        // creatureTemplate.baseStunResistance = Mathf.Lerp(creatureTemplate.baseStunResistance, creatureTemplate.baseDamageResistance, 0.1f);
                        break;

                    case CreatureTemplate.Type.Vulture:
                    case CreatureTemplate.Type.KingVulture:
                        creatureTemplate.baseDamageResistance = Mathf.Lerp(creatureTemplate.baseDamageResistance, 40f, 0.3f);
                        // creatureTemplate.baseStunResistance = Mathf.Lerp(creatureTemplate.baseStunResistance, creatureTemplate.baseDamageResistance, 0.1f);
                        break;

                    default:
                        if (creatureTemplate.baseDamageResistance > 4f && creatureTemplate.baseDamageResistance < 40f)
                        {
                            creatureTemplate.baseDamageResistance *= 1.2f;
                            // creatureTemplate.baseStunResistance = Mathf.Lerp(creatureTemplate.baseStunResistance, creatureTemplate.baseDamageResistance, 0.1f);
                        }
                        break;
                }

                orig.Invoke(self, world, creatureTemplate, realizedCreature, pos, ID);

                if (self.state is HealthState && self.creatureTemplate.type != CreatureTemplate.Type.Overseer && self.creatureTemplate.type != CreatureTemplate.Type.TentaclePlant)
                {
                    if (!MoreHealthStates.ContainsKey(self))
                    {
                        HealthAddState addState = new HealthAddState()
                        {
                            threshhold = Mathf.Max(1.5f, Mathf.Pow(self.creatureTemplate.baseStunResistance, 0.8f), self.creatureTemplate.baseDamageResistance / 4.0f),
                            comboDmg = 0f,
                            comboDrain = 0,
                            ignoreStun = 0
                        };
                        // Debug.Log(string.Concat("LancerCrit: ", self.creatureTemplate.type, " stunR: ", self.creatureTemplate.baseStunResistance, " dmgR: ", self.creatureTemplate.baseDamageResistance, " aState/thr: ", addState.threshhold));
                        MoreHealthStates.Add(self, addState);
                    }
                }
            }
            else
            { orig.Invoke(self, world, creatureTemplate, realizedCreature, pos, ID); }
        }

        public static void UpdatePatch(On.Creature.orig_Update orig, Creature self, bool eu)
        {
            orig.Invoke(self, eu);
            if (LancerMod.IsMelee && MoreHealthStates.TryGetValue(self.abstractCreature, out HealthAddState addState))
            { //eu &&
                addState.comboDrain = addState.comboDrain > 0 ? addState.comboDrain - 1 : 0;
                if (addState.comboDrain == 0) { addState.comboDmg = addState.comboDmg > 0.1f ? addState.comboDmg - 0.1f : 0f; }
                addState.ignoreStun = addState.ignoreStun > 0 ? addState.ignoreStun - 1 : 0;
                MoreHealthStates.Remove(self.abstractCreature);
                MoreHealthStates.Add(self.abstractCreature, addState);
            }
        }

        private static void ForceRelease(Creature self, BodyChunk source, Player player, int stun)
        {
            self.Stun(stun); //Custom.IntClamp(Mathf.FloorToInt(10f / self.Template.baseStunResistance), 3, 10)
            player.dangerGrasp.Release(); player.newToRoomInvinsibility = 15; player.stun = 0;
            source.owner.room.AddObject(new ExplosionSpikes(source.owner.room, source.owner.firstChunk.pos, 5, 5f, 8f, 4.5f, 40f, new Color(1f, 1f, 1f, 0.7f)));
            source.owner.room.PlaySound(source.owner is Spear ? SoundID.Spear_Bounce_Off_Creauture_Shell : SoundID.Rock_Bounce_Off_Creature_Shell, source.owner.firstChunk.pos, 1.4f, 0.7f);
            PlayerPatch.stats[player.playerState.playerNumber].fire = 0;
            PlayerPatch.stats[player.playerState.playerNumber].firedSpear = null;
        }

        public static void ViolencePatch(On.Creature.orig_Violence orig, Creature self, BodyChunk source, Vector2? directionAndMomentum, BodyChunk hitChunk, PhysicalObject.Appendage.Pos hitAppendage, Creature.DamageType type, float damage, float stunBonus)
        {
            orig.Invoke(self, source, directionAndMomentum, hitChunk, hitAppendage, type, damage, stunBonus);
            if (LancerMod.IsMelee && source?.owner is Weapon && (source.owner as Weapon).thrownBy is Player player)
            {
                bool isDanger = player.dangerGrasp != null && player.dangerGrasp.grabber == self;
                int stun = Custom.IntClamp(Mathf.FloorToInt(20f / self.Template.baseStunResistance), 3, 15) * (player.mainBodyChunk.vel.y < -1f ? -2 : 1);
                if (source.owner is Spear)
                {
                    if (isDanger)
                    { ForceRelease(self, source, player, stun); }
                    else
                    {
                        self.Stun(stun);
                        if (stun < 0)
                        {
                            source.owner.room.AddObject(new ExplosionSpikes(source.owner.room, source.owner.firstChunk.pos, 5, 4f, 6f, 4.5f, 30f, new Color(1f, 0.7f, 0.7f, 0.5f)));
                            source.owner.room.PlaySound(SoundID.Spear_Damage_Creature_But_Fall_Out, source.owner.firstChunk.pos, 1.2f, 0.7f);
                        }
                    }
                }
                else if (source.owner is Rock && isDanger)
                { ForceRelease(self, source, player, stun); }
            }
        }

        public static void LizViolencePatch(On.Lizard.orig_Violence orig, Lizard self, BodyChunk source, Vector2? directionAndMomentum, BodyChunk hitChunk, PhysicalObject.Appendage.Pos hitAppendage, Creature.DamageType type, float damage, float stunBonus)
        {
            orig.Invoke(self, source, directionAndMomentum, hitChunk, hitAppendage, type, damage, stunBonus);
            if (LancerMod.IsMelee && source?.owner is Weapon && (source.owner as Weapon).thrownBy is Player player)
            {
                bool isDanger = player.dangerGrasp != null && player.dangerGrasp.grabber == self;
                int stun = Custom.IntClamp(Mathf.FloorToInt(20f / self.Template.baseStunResistance), 3, 15) * (player.mainBodyChunk.vel.y < -1f ? -2 : 1);
                if (source.owner is Spear)
                {
                    if (isDanger)
                    { ForceRelease(self, source, player, stun); }
                    else
                    {
                        self.Stun(stun);
                        if (stun < 0)
                        {
                            source.owner.room.AddObject(new ExplosionSpikes(source.owner.room, source.owner.firstChunk.pos, 5, 4f, 6f, 4.5f, 30f, new Color(1f, 0.7f, 0.7f, 0.5f)));
                            source.owner.room.PlaySound(SoundID.Spear_Damage_Creature_But_Fall_Out, source.owner.firstChunk.pos, 1.2f, 0.7f);
                        }
                    }
                }
                else if (source.owner is Rock && isDanger)
                { ForceRelease(self, source, player, stun); }
            }
        }

        public static void StunPatch(On.Creature.orig_Stun orig, Creature self, int st)
        {
            if (LancerMod.IsMelee)
            {
                if (st < 0)
                {
                    orig.Invoke(self, -st);
                    return;
                } //Override Ignorestun
                if (MoreHealthStates.TryGetValue(self.abstractCreature, out HealthAddState addState))
                {
                    if (addState.ignoreStun > 0)
                    {
                        self.stun = Math.Min(self.stun, 10);
                        //Debug.Log(string.Concat("LancerCrit: ", self.Template.type, " ignoreStun ", addState.ignoreStun, "/combo: ", addState.comboDmg));
                        return;
                    }
                }

                orig.Invoke(self, st);
                //Debug.Log(string.Concat("LancerCrit: ", self.Template.type, " stun: ", self.stun));
                return;
            }
            orig.Invoke(self, st);
        }

        public static void LoadDefaultCommunity(On.CreatureCommunities.orig_LoadDefaultCommunityAlignments orig, CreatureCommunities self, int saveStateNumber)
        {
            if (!LancerMod.IsLancer) { orig.Invoke(self, saveStateNumber); return; }
            orig.Invoke(self, saveStateNumber == 1 ? 0 : saveStateNumber);
            if (saveStateNumber == 1)
            { //Lonk Reduce Reputation
                for (int p = 0; p < self.playerOpinions.GetLength(0); p++)
                {
                    for (int q = 0; q < self.playerOpinions.GetLength(1); q++)
                    {
                        for (int r = 0; r < self.playerOpinions.GetLength(2); r++)
                        {
                            self.playerOpinions[p, q, r] = Mathf.Lerp(self.playerOpinions[p, q, r], -1f, 0.15f);
                        }
                    }
                }
            }
        }
    }
}
