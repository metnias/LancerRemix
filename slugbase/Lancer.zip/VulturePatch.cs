﻿using RWCustom;
using UnityEngine;

namespace Lancer
{
    public static class VulturePatch
    {
        public static void Patch()
        {
            On.Vulture.Violence += new On.Vulture.hook_Violence(ViolencePatch);
            On.VultureMask.DrawSprites += new On.VultureMask.hook_DrawSprites(MaskDrawPatch);
            On.Scavenger.PickUpAndPlaceInInventory += new On.Scavenger.hook_PickUpAndPlaceInInventory(ScavPickUpPatch);
            On.LizardAI.DetermineBehavior += new On.LizardAI.hook_DetermineBehavior(LizardBehaviorPatch);
        }

        public static void ViolencePatch(On.Vulture.orig_Violence orig, Vulture vulture, BodyChunk source, Vector2? directionAndMomentum, BodyChunk hitChunk, PhysicalObject.Appendage.Pos onAppendagePos, Creature.DamageType type, float damage, float stunBonus)
        {
            bool playerSpear = source?.owner is Spear && (source?.owner as Spear).thrownBy is Player;
            if (hitChunk != null && hitChunk.index == 4 && (vulture.State as Vulture.VultureState).mask
                && damage <= 0.9f && playerSpear && UnityEngine.Random.value > 0.5f)
            {
                vulture.DropMask(((directionAndMomentum == null) ? new Vector2(0f, 0f) : (directionAndMomentum.Value / 5f)) + Custom.RNV() * 7f * UnityEngine.Random.value);
                damage *= 1.5f;
                //force stuck
                int slugcat = ((source.owner as Weapon).thrownBy as Player).playerState.playerNumber;
                source.owner.room.AddObject(new ExplosionSpikes(source.owner.room, source.owner.firstChunk.pos, 5, 4f, 6f, 4.5f, 30f, new Color(1f, 1f, 1f, 0.5f)));
                source.owner.room.PlaySound(SoundID.Spear_Fragment_Bounce, source.owner.firstChunk.pos, 1.2f, 0.8f);
                PlayerPatch.stats[slugcat].fire = 0;
                PlayerPatch.stats[slugcat].firedSpear = null;
            }
            float disencouraged = vulture.AI.disencouraged;
            orig.Invoke(vulture, source, directionAndMomentum, hitChunk, onAppendagePos, type, damage, stunBonus);
            if (LancerMod.IsMelee && playerSpear)
            { vulture.AI.disencouraged = (disencouraged * 1.5f + vulture.AI.disencouraged) / 2.5f; }
        }

        public static void MaskDrawPatch(On.VultureMask.orig_DrawSprites orig, VultureMask mask, RoomCamera.SpriteLeaser sLeaser, RoomCamera rCam, float timeStacker, Vector2 camPos)
        {
            Vector2 pos0, rotA, rotB;
            int slugcat;
            if (mask.grabbedBy.Count > 0 && mask.grabbedBy[0].grabber is Player)
            {
                slugcat = (mask.grabbedBy[0].grabber as Player).playerState.playerNumber;

                if (PlayerPatch.stats[slugcat].mask != null && PlayerPatch.stats[slugcat].mask.HasAMask && PlayerPatch.stats[slugcat].mask.mask != mask)
                {
                    mask.lastDonned = 0f; mask.donned = 0f; //don't put on mask
                    orig.Invoke(mask, sLeaser, rCam, timeStacker, camPos); return;
                }
            }
            PlayerGraphics pg;
            float lgt, don;
            for (int p = 0; p < PlayerPatch.stats.Length; p++)
            {
                if (PlayerPatch.stats[p].mask != null && PlayerPatch.stats[p].mask.HasAMask && PlayerPatch.stats[p].mask.mask == mask)
                {
                    pg = PlayerPatch.stats[p].mask.owner.graphicsModule as PlayerGraphics;

                    pos0 = Vector2.Lerp(mask.firstChunk.lastPos, mask.firstChunk.pos, timeStacker);
                    don = Mathf.Lerp(mask.lastDonned, mask.donned, timeStacker);
                    lgt = rCam.room.Darkness(pos0) * (1f - rCam.room.LightSourceExposure(pos0)) * 0.8f * (1f - mask.fallOffVultureMode);
                    rotA = Vector3.Slerp(mask.lastRotationA, mask.rotationA, timeStacker);
                    rotB = new Vector2(0f, 1f); //Vector3.Slerp(mask.lastRotationB, mask.rotationB, timeStacker);
                    slugcat = p;
                    goto StickedToHorn;
                }
            }
            orig.Invoke(mask, sLeaser, rCam, timeStacker, camPos);
            return;

        StickedToHorn:
            //if (don <= 0f) { goto ApplyChanges; }
            float view = Mathf.Lerp(mask.lastViewFromSide, mask.viewFromSide, timeStacker);
            Vector2 posM = Custom.DirVec(Vector2.Lerp(pg.drawPositions[1, 1], pg.drawPositions[1, 0], timeStacker), Vector2.Lerp(pg.drawPositions[0, 1], pg.drawPositions[0, 0], timeStacker));
            Vector2 pos0m = Vector2.Lerp(pg.drawPositions[0, 1], pg.drawPositions[0, 0], timeStacker) + posM * 3f;
            //pos0m = Vector2.Lerp(pos0m, Vector2.Lerp(pg.head.lastPos, pg.head.pos, timeStacker) + posM * 3f, 0.5f);
            pos0m = Vector2.Lerp(pos0m, Vector2.Lerp(pg.head.lastPos, pg.head.pos, timeStacker) - posM * 6f, 0.5f);
            pos0m += Vector2.Lerp(pg.lastLookDir, pg.lookDirection, timeStacker) * 1.5f;
            rotA = Vector3.Slerp(rotA, posM, don);
            if ((pg.owner as Player).eatCounter < 35)
            { //eating
                rotB = Vector3.Slerp(rotB, new Vector2(0f, -1f), don); //don
                pos0m += posM * Mathf.InverseLerp(35f, 15f, (float)(pg.owner as Player).eatCounter) * 9f;
                //Custom.LerpMap((float)(pg.owner as Player).eatCounter, 35f, 15f, 0f, 0.11f)
            }
            else
            {
                rotB = Vector3.Slerp(rotB, new Vector2(0f, 1f), don);
            }
            if (view != 0f)
            {
                rotA = Custom.DegToVec(Custom.VecToDeg(rotA) - 20f * view);
                rotB = Vector3.Slerp(rotB, Custom.DegToVec(-50f * view), Mathf.Abs(view));
                pos0m += posM * 2f * Mathf.Abs(view);
                pos0m -= Custom.PerpendicularVector(posM) * 4f * view;
            }
            pos0 = Vector2.Lerp(pos0, pos0m, don);
            //ApplyChanges:
            float deg = Custom.VecToDeg(rotB);
            int idx = Custom.IntClamp(Mathf.RoundToInt(Mathf.Abs(deg / 180f) * 8f), 0, 8);
            float size = (!mask.King) ? 1f : 1.15f;
            for (int i = 0; i < ((!mask.King) ? 3 : 4); i++)
            {
                sLeaser.sprites[i].element = Futile.atlasManager.GetElementWithName(((i != 3) ? "KrakenMask" : "KrakenArrow") + idx);
                sLeaser.sprites[i].rotation = Custom.VecToDeg(rotA);
                sLeaser.sprites[i].x = pos0.x - camPos.x;
                sLeaser.sprites[i].y = pos0.y - camPos.y;
                sLeaser.sprites[i].anchorY = Custom.LerpMap(Mathf.Abs(deg), 0f, 100f, 0.5f, 0.675f, 2.1f);
                sLeaser.sprites[i].anchorX = 0.5f - rotB.x * 0.1f * Mathf.Sign(deg);
            }
            sLeaser.sprites[1].scaleX *= 0.85f * size;
            sLeaser.sprites[1].scaleY = 0.9f * size;
            sLeaser.sprites[2].scaleY = 1.1f * size;
            sLeaser.sprites[2].anchorY += 0.015f;

            if (mask.blink > 0 && UnityEngine.Random.value < 0.5f)
            {
                for (int j = 0; j < ((!mask.King) ? 3 : 4); j++)
                { sLeaser.sprites[j].color = new Color(1f, 1f, 1f); }
            }
            else
            {
                PlayerPatch.stats[slugcat].mask.color = Color.Lerp(Color.Lerp(PlayerPatch.stats[slugcat].mask.ColorA.rgb, new Color(1f, 1f, 1f), 0.35f * mask.fallOffVultureMode), PlayerPatch.stats[slugcat].mask.blackColor, Mathf.Lerp(0.2f, 1f, Mathf.Pow(lgt, 2f)));
                sLeaser.sprites[0].color = PlayerPatch.stats[slugcat].mask.color;
                sLeaser.sprites[1].color = Color.Lerp(PlayerPatch.stats[slugcat].mask.color, PlayerPatch.stats[slugcat].mask.blackColor, Mathf.Lerp(0.75f, 1f, lgt));
                sLeaser.sprites[2].color = Color.Lerp(PlayerPatch.stats[slugcat].mask.color, PlayerPatch.stats[slugcat].mask.blackColor, Mathf.Lerp(0.75f, 1f, lgt));
                if (mask.King)
                {
                    sLeaser.sprites[3].color = Color.Lerp(Color.Lerp(Color.Lerp(HSLColor.Lerp(PlayerPatch.stats[slugcat].mask.ColorA, PlayerPatch.stats[slugcat].mask.ColorB, 0.8f - 0.3f * mask.fallOffVultureMode).rgb, PlayerPatch.stats[slugcat].mask.blackColor, 0.53f),
                        Color.Lerp(PlayerPatch.stats[slugcat].mask.ColorA.rgb, new Color(1f, 1f, 1f), 0.35f), 0.1f), PlayerPatch.stats[slugcat].mask.blackColor, 0.6f * lgt);
                }
            }
            if (mask.slatedForDeletetion || mask.room != rCam.room)
            {
                sLeaser.CleanSpritesAndRemove();
            }
        }

        public static LizardAI.Behavior LizardBehaviorPatch(On.LizardAI.orig_DetermineBehavior orig, LizardAI ai)
        {
            Tracker.CreatureRepresentation rep = null;
            Player player = null;
            for (int i = 0; i < ai.tracker.CreaturesCount; i++)
            {
                rep = ai.tracker.GetRep(i);
                if (rep.representedCreature != null && rep.representedCreature.creatureTemplate.type == CreatureTemplate.Type.Slugcat)
                {
                    if (rep.representedCreature.realizedCreature != null) { player = rep.representedCreature.realizedCreature as Player; break; }
                }
            }
            if (player != null && ai.creature.creatureTemplate.type != CreatureTemplate.Type.BlackLizard && ai.creature.creatureTemplate.type != CreatureTemplate.Type.RedLizard)
            {
                if (rep.VisualContact && PlayerPatch.stats[player.playerState.playerNumber].mask != null && PlayerPatch.stats[player.playerState.playerNumber].mask.HasAMask)
                {
                    bool king = PlayerPatch.stats[player.playerState.playerNumber].mask.mask.King;
                    if (ai.usedToVultureMask < (!king ? 700 : 1200))
                    {
                        ai.usedToVultureMask += 2;
                        if (ai.creature.creatureTemplate.type == CreatureTemplate.Type.GreenLizard && !king)
                        {
                            rep.dynamicRelationship.currentRelationship = new CreatureTemplate.Relationship(CreatureTemplate.Relationship.Type.Ignores, 0f);
                        }
                        else
                        {
                            rep.dynamicRelationship.currentRelationship = new CreatureTemplate.Relationship(CreatureTemplate.Relationship.Type.Afraid,
                                Mathf.InverseLerp((float)(!king ? 700 : 1200), 600f, (float)ai.usedToVultureMask)
                                * (!king ? ((ai.creature.creatureTemplate.type != CreatureTemplate.Type.BlueLizard) ? 0.4f : 0.6f) //0.6 0.8
                                : ((ai.creature.creatureTemplate.type != CreatureTemplate.Type.GreenLizard) ? 0.7f : 0.3f))); //0.9 0.4
                        }

                        ai.preyTracker.ForgetPrey(player.abstractCreature);
                        ai.threatTracker.AddThreatCreature(rep);
                    }
                }
            }

            return orig.Invoke(ai);
        }

        public static void ScavPickUpPatch(On.Scavenger.orig_PickUpAndPlaceInInventory orig, Scavenger scav, PhysicalObject obj)
        {
            if (obj is VultureMask mask)
            {
                for (int p = 0; p < PlayerPatch.stats.Length; p++)
                {
                    if (PlayerPatch.stats[p].mask != null)
                    { if (PlayerPatch.stats[p].mask.HasAMask && PlayerPatch.stats[p].mask.mask == mask) { return; } }
                }
            }

            orig.Invoke(scav, obj);
        }
    }
}