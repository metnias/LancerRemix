using Partiality.Modloader;
using UnityEngine;

namespace Lancer
{
    public class LancerMod : PartialityMod
    {
        public static LancerScript script;
        public static LancerConfig config;

        public LancerMod()
        {
            ModID = "Lancer";
            Version = "0973";
            author = "topicular";
        }

        public override void OnEnable()
        {
            base.OnEnable();
            GameObject go = new GameObject();
            script = go.AddComponent<LancerScript>();
            LancerScript.mod = this;
            config = new LancerConfig
            {
                configMachine = false,
                hasHorn = true, //!File.Exists(string.Concat(Custom.RootFolderDirectory(), "nohorn.txt"))
                isPup = true,
                hornColor = new Color[4] { Color.black, Color.black, Color.black, Color.white },
                canPullSpear = true,
                spearGrability = false,
                melee = true,
                grape = false,
                disabled = false,
                translate = false
            };

            script.Initialize();
        }

        public static bool EnableHorn => !config.disabled && config.hasHorn;
        public static bool IsMelee => !config.disabled && config.melee;
        public static bool IsLancer => !config.disabled && config.melee && config.isPup;
        public static bool IsPup => !config.disabled && config.isPup;

        public struct LancerConfig
        {
            public bool configMachine;
            public bool hasHorn;
            public Color[] hornColor;
            public bool isPup;
            public bool canPullSpear;
            public bool spearGrability;
            public bool melee;
            public bool grape;

            public bool disabled;
            public bool translate;
        }

        //public static bool lancerDialogue = true;
        public static bool useCustomColor = false;

        public static LancerOption oi;

        public static LancerOption LoadOI()
        {
            oi = new LancerOption(); return oi;
        }

        public static string Translate(string orig)
        {
            if (config.translate) { return oi.Translate(orig); }
            return orig;
        }
    }
}
