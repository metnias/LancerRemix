﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using RWCustom;

namespace Lancer
{
    public static class RockPatch
    {
        public static bool HitPatch(On.Rock.orig_HitSomething orig, Rock rock, SharedPhysics.CollisionResult result, bool eu)
        {
            if (LancerMod.config.configMachine && !LancerMod.config.lancer)
            {
                return orig.Invoke(rock, result, eu);
            }
            if (result.obj == null)
            {
                return false;
            }
            bool value = orig.Invoke(rock, result, eu);
            if (result.obj is Creature && rock.thrownBy is Player && UnityEngine.Random.value < 0.3f)
            {
                int slugcat = (rock.thrownBy as Player).playerState.playerNumber;
                PlayerPatch.fire[slugcat] = 0;
                PlayerPatch.firedWeapon[slugcat] = null;
                rock.room.AddObject(new ExplosionSpikes(rock.room, result.chunk.pos + Custom.DirVec(result.chunk.pos,
                    result.collisionPoint) * result.chunk.rad, 5, 2f, 4f, 4.5f, 30f, new Color(1f, 1f, 1f, 0.5f)));
                rock.room.PlaySound(SoundID.Rock_Bounce_Off_Creature_Shell, rock.firstChunk.pos, 1.3f, 0.6f);
                rock.Destroy();
            }
            return value;
        }
    }
}