using Menu;
using RWCustom;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEngine;

namespace Lancer
{
    public static class PlayerGraphicsPatch
    {
        public static void Patch()
        {
            On.PlayerGraphics.ctor += new On.PlayerGraphics.hook_ctor(CtorPatch);
            On.PlayerGraphics.SlugcatColor += new On.PlayerGraphics.hook_SlugcatColor(ColorPatch);
            On.PlayerGraphics.InitiateSprites += new On.PlayerGraphics.hook_InitiateSprites(InitSprPatch);
            On.PlayerGraphics.ApplyPalette += new On.PlayerGraphics.hook_ApplyPalette(ApplyPltPatch);
            On.PlayerGraphics.DrawSprites += new On.PlayerGraphics.hook_DrawSprites(DrawSprPatch);
            On.PlayerGraphics.AddToContainer += new On.PlayerGraphics.hook_AddToContainer(AddCtnerPatch);
            On.Menu.MenuIllustration.ctor += new On.Menu.MenuIllustration.hook_ctor(MenuIllustCtorPatch);
            ArenaPortraits = new string[]
            {
                "MultiplayerPortrait00",
                "MultiplayerPortrait01",
                "MultiplayerPortrait10",
                "MultiplayerPortrait11",
                "MultiplayerPortrait20",
                "MultiplayerPortrait21",
                "MultiplayerPortrait30",
                "MultiplayerPortrait31"
            };
        }

        public static void CtorPatch(On.PlayerGraphics.orig_ctor orig, PlayerGraphics instance, PhysicalObject ow)
        {
            orig.Invoke(instance, ow);
            if (!LancerMod.IsPup) { return; }

            instance.tail = new TailSegment[4];
            instance.tail[0] = new TailSegment(instance, 4f, 2f, null, 0.85f, 1f, 0.5f, true);
            instance.tail[1] = new TailSegment(instance, 3f, 3f, instance.tail[0], 0.85f, 1f, 0.5f, true);
            instance.tail[2] = new TailSegment(instance, 1f, 1f, instance.tail[1], 0.85f, 1f, 0.5f, true);
            instance.tail[3] = new TailSegment(instance, 0.3f, 0.3f, instance.tail[2], 0.85f, 1f, 0.5f, true);
        }

        private static bool extraSlug = false;

        public static Color ColorPatch(On.PlayerGraphics.orig_SlugcatColor orig, int slugcat)
        {
            Color result = orig.Invoke(0);
            if (extraSlug || result != Color.white || (!LancerMod.IsPup && !LancerMod.config.grape)) { LancerMod.useCustomColor = true; return orig.Invoke(slugcat); } //Custom Color
            switch (slugcat)
            {
                case 0: //Survivor - Green
                    result = new Color(0.8f, 1f, 0.5f); break;
                case 1: //Monk - Orange
                    result = new Color(1f, 0.9f, 0.4f); break;
                case 2: //Hunter - Blue
                    result = new Color(0.3f, 0.5f, 1f); break;
                default:
                case 3: //Nightcat - Magenta
                    result = new Color(0.8f, 0.1f, 0.3f); break;
            }
            LancerMod.useCustomColor = false;
            if (LancerMod.config.grape) { result = new Color(0.3f, 0f, 0.5f); }
            return result;
        }

        public static Color[] defaultHornColor = new Color[4]
        {
            new Color(0.1f, 0.3f, 0.0f),
            new Color(0.5f, 0.1f, 0.0f),
            new Color(0.0f, 0.1f, 0.5f),
            new Color(0.1f, 0.5f, 0.3f)
        };

        public static void ApplyPltPatch(On.PlayerGraphics.orig_ApplyPalette orig, PlayerGraphics instance, RoomCamera.SpriteLeaser sLeaser, RoomCamera rCam, RoomPalette palette)
        {
            orig.Invoke(instance, sLeaser, rCam, palette);
            int slugcat = (instance.owner as Player).playerState.slugcatCharacter;
            if (!LancerMod.config.disabled && !LancerMod.useCustomColor && (slugcat == 3 || LancerMod.config.grape))
            { // Fix Nightcat Colour
                Color bodyColor = PlayerGraphics.SlugcatColor(slugcat);
                Color eyeColor = Color.Lerp(new Color(1f, 1f, 1f), palette.blackColor, 0.3f);
                float mal = (!(instance.owner as Player).Malnourished) ? Mathf.Max(0f, instance.malnourished - 0.005f) : instance.malnourished;
                bodyColor = Color.Lerp(bodyColor, Color.gray, 0.4f * mal);
                for (int i = 0; i < 9; i++)
                {
                    sLeaser.sprites[i].color = bodyColor;
                }
                sLeaser.sprites[11].color = Color.Lerp(PlayerGraphics.SlugcatColor(slugcat), Color.white, 0.3f);
                sLeaser.sprites[10].color = PlayerGraphics.SlugcatColor(slugcat);
                sLeaser.sprites[9].color = eyeColor;
            }
            if (!LancerMod.EnableHorn) { return; }
            int horn = PlayerPatch.stats[(instance.owner as Player).playerState.playerNumber].horn;
            if (!LancerMod.config.configMachine)
            {
                if (!LancerMod.useCustomColor && slugcat <= 3) { sLeaser.sprites[horn].color = defaultHornColor[slugcat]; }
                else { sLeaser.sprites[horn].color = InvertColor(sLeaser.sprites[0].color); }
            }
            else
            {
                sLeaser.sprites[horn].color = LancerMod.config.hornColor[Custom.IntClamp(slugcat, 0, 3)];
            }
        }

        public static void InitSprPatch(On.PlayerGraphics.orig_InitiateSprites orig, PlayerGraphics instance, RoomCamera.SpriteLeaser sLeaser, RoomCamera rCam)
        {
            if (rCam.room.game.IsArenaSession) { extraSlug = false; }
            else if (!extraSlug) { if ((instance.owner as Player).playerState.slugcatCharacter > 2) { extraSlug = true; } }
            int player = (instance.owner as Player).playerState.playerNumber;
            PlayerPatch.stats[player].horn = int.MaxValue;
            orig.Invoke(instance, sLeaser, rCam);
            if (LancerMod.IsPup) { sLeaser.sprites[3].scale = 0.8f; }
            if (!LancerMod.EnableHorn) { return; }

            PlayerPatch.stats[player].horn = sLeaser.sprites.Length;
            Array.Resize(ref sLeaser.sprites, sLeaser.sprites.Length + 1);
            TriangleMesh.Triangle[] tris = new TriangleMesh.Triangle[]
            { new TriangleMesh.Triangle(0, 1, 2)};
            TriangleMesh triangleMesh = new TriangleMesh("Futile_White", tris, false, false);
            sLeaser.sprites[PlayerPatch.stats[player].horn] = triangleMesh;
            //sLeaser.sprites[horn[slugcat]] = new FSprite("Futile_White", true);
            //sLeaser.sprites[horn[slugcat]].scale = 10f;

            instance.AddToContainer(sLeaser, rCam, null);
            PlayerPatch.stats[player].hornOverlay = true;
        }

        public static IntVector2 HornStat(int slugcat)
        {
            IntVector2 result; // = new IntVector2(3, 8);
            switch (slugcat)
            {
                default:
                case 0:
                case 3:
                    result = new IntVector2(3, 8); break;
                case 1:
                    result = new IntVector2(4, 7); break;
                case 2:
                    result = new IntVector2(4, 9); break;
            }
            return result;
        }

        public static void DrawSprPatch(On.PlayerGraphics.orig_DrawSprites orig, PlayerGraphics instance, RoomCamera.SpriteLeaser sLeaser, RoomCamera rCam, float timeStacker, Vector2 camPos)
        {
            orig.Invoke(instance, sLeaser, rCam, timeStacker, camPos);

            //Vector2 draw0 = Vector2.Lerp(instance.drawPositions[0, 1], instance.drawPositions[0, 0], timeStacker);
            Vector2 draw1 = Vector2.Lerp(instance.drawPositions[1, 1], instance.drawPositions[1, 0], timeStacker);
            Vector2 head = Vector2.Lerp(instance.head.lastPos, instance.head.pos, timeStacker);

            IntVector2 stat = HornStat((instance.owner as Player).playerState.slugcatCharacter);
            Vector2 tip = head + Custom.DirVec(draw1, head) * (float)stat.y;
            Vector2 thicc = Custom.PerpendicularVector(head, tip);

            if (LancerMod.IsPup)
            {
                Vector2 hand = Vector2.Lerp(instance.hands[0].lastPos, instance.hands[0].pos, timeStacker);
                sLeaser.sprites[5].x = hand.x + thicc.x * 5f - camPos.x;
                sLeaser.sprites[5].y = hand.y + thicc.y * 5f - camPos.y;
                hand = Vector2.Lerp(instance.hands[1].lastPos, instance.hands[1].pos, timeStacker);
                sLeaser.sprites[6].x = hand.x - thicc.x * 5f - camPos.x;
                sLeaser.sprites[6].y = hand.y - thicc.y * 5f - camPos.y;
            }

            if (!LancerMod.EnableHorn) { return; }

            Vector2 dir = (tip - head) * 0.6f;
            int slugcat = (instance.owner as Player).playerState.playerNumber;

            (sLeaser.sprites[PlayerPatch.stats[slugcat].horn] as TriangleMesh).MoveVertice(0, dir + tip - camPos);
            (sLeaser.sprites[PlayerPatch.stats[slugcat].horn] as TriangleMesh).MoveVertice(1, dir + head - thicc * (float)stat.x / 2f - camPos);
            (sLeaser.sprites[PlayerPatch.stats[slugcat].horn] as TriangleMesh).MoveVertice(2, dir + head + thicc * (float)stat.x / 2f - camPos);
            //sLeaser.sprites[horn[slugcat]].SetPosition(head - camPos);
            if (PlayerPatch.stats[slugcat].hornOverlay == PlayerPatch.stats[slugcat].mask.HasAMask)
            { //switch overrap for horn
                PlayerPatch.stats[slugcat].hornOverlay = !PlayerPatch.stats[slugcat].mask.HasAMask;
                SwitchHornOverlap(instance, sLeaser, rCam, PlayerPatch.stats[slugcat].hornOverlay);
            }
        }

        public static void AddCtnerPatch(On.PlayerGraphics.orig_AddToContainer orig, PlayerGraphics instance, RoomCamera.SpriteLeaser sLeaser, RoomCamera rCam, FContainer newContainer)
        {
            orig.Invoke(instance, sLeaser, rCam, newContainer);
            int horn = PlayerPatch.stats[(instance.owner as Player).playerState.playerNumber].horn;
            if (sLeaser.sprites.Length <= horn) { return; }
            sLeaser.sprites[horn].RemoveFromContainer();
            if (newContainer == null)
            {
                newContainer = rCam.ReturnFContainer("Midground");
            }
            newContainer.AddChild(sLeaser.sprites[horn]);
        }

        public static void SwitchHornOverlap(PlayerGraphics instance, RoomCamera.SpriteLeaser sLeaser, RoomCamera rCam, bool newOverlap)
        {
            sLeaser.sprites[PlayerPatch.stats[(instance.owner as Player).playerState.playerNumber].horn].RemoveFromContainer();
            FContainer newContainer = rCam.ReturnFContainer(newOverlap ? "Midground" : "Foreground");
            newContainer.AddChild(sLeaser.sprites[PlayerPatch.stats[(instance.owner as Player).playerState.playerNumber].horn]);
        }

        public static Color InvertColor(Color ColorToInvert)
        {
            return new Color(1.0f - ColorToInvert.r,
              1.0f - ColorToInvert.g, 1.0f - ColorToInvert.b);
        }

        private static string[] ArenaPortraits;

        private static void MenuIllustCtorPatch(On.Menu.MenuIllustration.orig_ctor orig, MenuIllustration illust,
            Menu.Menu menu, MenuObject owner, string folderName, string fileName, Vector2 pos, bool crispPixels, bool anchorCenter)
        {
            if (string.IsNullOrEmpty(folderName) && LancerMod.IsLancer && ArenaPortraits.Contains(fileName))
            {
                #region baseCtor

                illust.menu = menu;
                illust.owner = owner;
                illust.subObjects = new List<MenuObject>();
                illust.nextSelectable = new MenuObject[4];
                illust.pos = pos;
                illust.lastPos = pos;
                illust.size = Vector2.zero;

                #endregion baseCtor

                illust.folderName = folderName;
                illust.fileName = "Lancer" + fileName;
                illust.crispPixels = crispPixels;
                illust.anchorCenter = anchorCenter;

                CustomIllustLoad(illust);

                illust.sprite = new FSprite(illust.fileName, true);
                if (!anchorCenter)
                {
                    illust.sprite.anchorX = 0f;
                    illust.sprite.anchorY = 0f;
                }
                illust.sprite.alpha = 0f;
                illust.spriteAdded = true;
                illust.Container.AddChild(illust.sprite);
                illust.size = new Vector2((float)illust.texture.width, (float)illust.texture.height);
                illust.alpha = 1f;
                illust.lastAlpha = 1f;
            }
            else { orig.Invoke(illust, menu, owner, folderName, fileName, pos, crispPixels, anchorCenter); }
        }

        private static void CustomIllustLoad(MenuIllustration illust)
        {
            string tempPath = string.Concat(Custom.RootFolderDirectory(), illust.fileName, ".png");
            File.WriteAllBytes(tempPath, DataManager.ReadBytes(illust.fileName));
            illust.www = new WWW(string.Concat("file:///", tempPath));

            //illust.www = new WWW(string.Concat("file:///", SporeMod.resourcePath, folder, Path.DirectorySeparatorChar, illust.fileName, ".png"));
            illust.texture = new Texture2D(1, 1, TextureFormat.ARGB32, false) { wrapMode = TextureWrapMode.Clamp };
            if (illust.crispPixels)
            {
                illust.texture.anisoLevel = 0;
                illust.texture.filterMode = FilterMode.Point;
            }
            illust.www.LoadImageIntoTexture(illust.texture);
            HeavyTexturesCache.LoadAndCacheAtlasFromTexture(illust.fileName, illust.texture);
            illust.www = null;
            File.Delete(tempPath);
        }
    }
}