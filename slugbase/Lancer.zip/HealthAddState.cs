﻿namespace Lancer
{
    public static partial class CreaturePatch
    {
        public struct HealthAddState
        {
            public float threshhold;
            public float comboDmg;
            public int comboDrain;
            public int ignoreStun;
        }
    }
}