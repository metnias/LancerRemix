﻿using System.Collections.Generic;
using UnityEngine;

namespace Lancer
{
    public static class SLOracleBehaviorPatch
    {
        public static void Patch()
        {
            On.SLOracleBehaviorHasMark.NameForPlayer += new On.SLOracleBehaviorHasMark.hook_NameForPlayer(PlayerNamePatch);
            On.SLOracleBehaviorHasMark.MoonConversation.AddEvents += new On.SLOracleBehaviorHasMark.MoonConversation.hook_AddEvents(AddEventPatch);
        }

        public static string PlayerNamePatch(On.SLOracleBehaviorHasMark.orig_NameForPlayer orig, SLOracleBehaviorHasMark instance, bool capitalized)
        {
            if (!LancerMod.IsLancer)
            {
                return orig.Invoke(instance, capitalized);
            }
            string text = "animal";
            bool flag = instance.DamagedMode && UnityEngine.Random.value < 0.5f;
            if (UnityEngine.Random.value > 0.2f)
            {
                switch (instance.State.GetOpinion)
                {
                    case SLOrcacleState.PlayerOpinion.Dislikes:
                        text = "imp"; break;
                    case SLOrcacleState.PlayerOpinion.Likes:
                        if (instance.State.totalPearlsBrought > 5 && !instance.DamagedMode)
                        {
                            text = "student";
                        }
                        else
                        {
                            text = "child";
                        }
                        break;

                    default:
                        text = "creature";
                        break;
                }
            }

            return ((!capitalized) ? "tiny" : "Tiny") + ((!flag) ? " " : "... ") + text;
        }

        public static void AddEventPatch(On.SLOracleBehaviorHasMark.MoonConversation.orig_AddEvents orig, SLOracleBehaviorHasMark.MoonConversation instance)
        {
            if (!LancerMod.IsLancer)
            {
                orig.Invoke(instance); return;
            }
            Debug.Log("SLOracle.AddEvents patched by Lancer Mod!");
            Conversation.ID backupID = instance.id;
            List<Conversation.DialogueEvent> backupList = new List<Conversation.DialogueEvent>();
            for (int p = 0; p < instance.events.Count; p++)
            {
                backupList.Add(instance.events[p]);
            }
            string check = instance.Translate("Hi! Little saviour!").Substring(0, 10);
            instance.id = Conversation.ID.Moon_Red_Second_Conversation;
            orig.Invoke(instance);
            instance.id = backupID;
            for (int c = 0; c < instance.events.Count; c++)
            {
                if (instance.events[c] is Conversation.TextEvent && (instance.events[c] as Conversation.TextEvent).text.Length > 10)
                {
                    string id = (instance.events[c] as Conversation.TextEvent).text.Substring(0, 10);
                    if (check == id) { goto lanceEvent; }
                }
            }
            //Modded
            instance.events = new List<Conversation.DialogueEvent>();
            for (int p = 0; p < backupList.Count; p++)
            {
                instance.events.Add(backupList[p]);
            }
            //LancerMod.lancerDialogue = false;
            orig.Invoke(instance);
            return;
        lanceEvent:
            Debug.Log("Using Lancer Dialogue for Moon: " + instance.id.ToString() + "/" + instance.State.neuronsLeft.ToString());
            //LancerMod.lancerDialogue = true;
            instance.events = new List<Conversation.DialogueEvent>();
            for (int p = 0; p < backupList.Count; p++)
            {
                instance.events.Add(backupList[p]);
            }
            switch (instance.id)
            {
                case Conversation.ID.MoonFirstPostMarkConversation:
                    switch (instance.State.neuronsLeft)
                    {
                        case 1:
                            instance.events.Add(new Conversation.TextEvent(instance, 40, "...", 10));
                            break;

                        case 2:
                            instance.events.Add(new Conversation.TextEvent(instance, 30, LancerMod.Translate("Get... get away... small.... thing."), 10));
                            instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("Please... thiss all I have left."), 10));
                            break;

                        case 3:
                            instance.events.Add(new Conversation.TextEvent(instance, 30, instance.Translate("You!"), 10));
                            instance.events.Add(new Conversation.TextEvent(instance, 60, instance.Translate("...you ate... me. Please go away. I won't speak... to you.<LINE>I... CAN'T speak to you... because... you ate...me..."), 0));
                            break;

                        case 4:
                            instance.LoadEventsFromFile(35);
                            //instance.events.Add(new Conversation.TextEvent(instance, 0, "Oh so you've returned.", 0));
                            //instance.events.Add(new Conversation.TextEvent(instance, 0, "Come to take more from me? My memories, my thoughts... just something to fill your stomach?", 0));
                            //instance.events.Add(new Conversation.TextEvent(instance, 0, "No... never mind.", 0));
                            //instance.events.Add(new Conversation.TextEvent(instance, 0, "It's useless to be angry at an animal following its instincts. Once, a single neuron meant nothing to me...", 0));
                            instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("I see that someone has given you the gift of communication.<LINE>Must have been Five Pebbles, as you don't look like you can travel very far at all..."), 0));
                            instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("He's sick, if you haven't noticed. Being corrupted from the inside by his own experiments. Maybe they all are by now, who knows.<LINE>We weren't designed to transcend and it drives us mad."), 0));
                            instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("It is good to have someone to talk to after all this time even if that's a child like you.<LINE>The scavengers aren't exactly good listeners. They do bring me things though, occasionally..."), 0));
                            break;

                        case 5:
                            instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("Hello <PlayerName>."), 0));
                            instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("What are you? If I had my memories I would know..."), 0));
                            if (instance.State.playerEncounters > 0 && instance.State.playerEncountersWithMark == 0)
                            {
                                instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("Perhaps... I saw you before?"), 0));
                            }
                            instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("You must be very brave to have made it all the way here. But I'm sorry to say your journey here is in vain."), 5));
                            instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("As you can see, I have nothing for you. Not even my memories."), 0));
                            instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("Or did I say that already?"), 5));
                            instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("I see that someone has given you the gift of communication.<LINE>Must have been Five Pebbles, as you don't look like you can travel very far at all..."), 0));
                            instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("He's sick, if you haven't noticed. Being corrupted from the inside by his own experiments. Maybe they all are by now, who knows.<LINE>We weren't designed to transcend and it drives us mad."), 0));
                            instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("It is good to have someone to talk to after all this time even if that's a child like you.<LINE>The scavengers aren't exactly good listeners. They do bring me things though, occasionally..."), 0));
                            break;
                    }
                    break;

                case Conversation.ID.MoonSecondPostMarkConversation:
                    switch (instance.State.neuronsLeft)
                    {
                        case 1:
                            instance.events.Add(new Conversation.TextEvent(instance, 40, "...", 10));
                            break;

                        case 2:
                            instance.events.Add(new Conversation.TextEvent(instance, 80, instance.Translate("...leave..."), 10));
                            break;

                        case 3:
                            instance.events.Add(new Conversation.TextEvent(instance, 20, instance.Translate("You..."), 10));
                            instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("Please don't... take... more from me... Go."), 0));
                            break;

                        case 4:
                            if (instance.State.GetOpinion == SLOrcacleState.PlayerOpinion.Dislikes)
                            {
                                instance.events.Add(new Conversation.TextEvent(instance, 30, instance.Translate("Oh. You."), 0));
                            }
                            else
                            {
                                if (instance.State.GetOpinion == SLOrcacleState.PlayerOpinion.Likes)
                                {
                                    instance.events.Add(new Conversation.TextEvent(instance, 30, instance.Translate("Hello there! You again!"), 0));
                                }
                                else
                                {
                                    instance.events.Add(new Conversation.TextEvent(instance, 30, instance.Translate("Hello there. You again!"), 0));
                                }
                                instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("I wonder what it is that you want?"), 0));
                                if (instance.State.GetOpinion != SLOrcacleState.PlayerOpinion.Dislikes)
                                {
                                    instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("I have had scavengers come by before. Scavengers!<LINE>And they left me alive!<LINE>But... I have told you that already, haven't I?"), 0));
                                    instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("You must excuse me if I repeat myself. My memory is bad.<LINE>I used to have a pathetic five neurons... And then you ate one.<LINE>Maybe I've told you that before as well."), 0));
                                }
                            }
                            break;

                        case 5:
                            if (instance.State.GetOpinion == SLOrcacleState.PlayerOpinion.Dislikes)
                            {
                                instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("You again."), 10));
                            }
                            else
                            {
                                if (instance.State.GetOpinion == SLOrcacleState.PlayerOpinion.Likes)
                                {
                                    instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("Oh, hello!"), 10));
                                }
                                else
                                {
                                    instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("Oh, hello."), 10));
                                }
                                instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("I wonder what it is that you want?"), 0));
                                if (instance.State.GetOpinion != SLOrcacleState.PlayerOpinion.Dislikes)
                                {
                                    instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("There is nothing here. Not even my memories remain."), 0));
                                    instance.events.Add(new Conversation.TextEvent(instance, 30, instance.Translate("Even the scavengers that come here from time to time leave with nothing. But... I have told you that already, haven't I?"), 0));
                                    if (instance.State.GetOpinion == SLOrcacleState.PlayerOpinion.Likes)
                                    {
                                        instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("I do enjoy the company though. You're welcome to stay a while, quiet petite thing."), 5));
                                    }
                                }
                            }
                            break;
                    }
                    break;

                case Conversation.ID.MoonRecieveSwarmer:
                    {
                        if (instance.State.neuronsLeft - 1 > 2 && instance.slOracleBehaviorHasMark.respondToNeuronFromNoSpeakMode)
                        {
                            instance.events.Add(new Conversation.TextEvent(instance, 10, instance.Translate("You... Strange thing. Now this?"), 10));
                            instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("I will accept your gift..."), 10));
                        }
                        int num = instance.State.neuronsLeft - 1;
                        switch (num + 1)
                        {
                            case 0:
                            case 1:
                                break;

                            case 2:
                                instance.events.Add(new Conversation.TextEvent(instance, 40, "...", 10));
                                instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("You!"), 10));
                                instance.events.Add(new Conversation.TextEvent(instance, 10, instance.Translate("...you...killed..."), 10));
                                instance.events.Add(new Conversation.TextEvent(instance, 0, "...", 10));
                                instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("...me"), 10));
                                break;

                            case 3:
                                instance.events.Add(new Conversation.TextEvent(instance, 10, instance.Translate("...thank you... better..."), 10));
                                instance.events.Add(new Conversation.TextEvent(instance, 20, instance.Translate("still, very... bad."), 10));
                                break;

                            case 4:
                                instance.events.Add(new Conversation.TextEvent(instance, 20, instance.Translate("Thank you... That is a little better. Thank you, creature."), 10));
                                if (!instance.slOracleBehaviorHasMark.respondToNeuronFromNoSpeakMode)
                                {
                                    instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.Translate("Maybe this is asking too much for a child like you but... could you bring me another one?"), 0));
                                }
                                break;

                            default:
                                if (instance.slOracleBehaviorHasMark.respondToNeuronFromNoSpeakMode)
                                {
                                    instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("Thank you. I do wonder what you want."), 10));
                                }
                                else
                                {
                                    if (instance.State.neuronGiveConversationCounter == 0)
                                    {
                                        Debug.Log("moon recieve first neuron. Has neurons: " + instance.State.neuronsLeft);
                                        if (instance.State.neuronsLeft == 5)
                                        {
                                            instance.LoadEventsFromFile(45);
                                            //instance.events.Add(new Conversation.TextEvent(instance, 0, LancerMod.oi.Translate("After all this time, a lifeline. Thank you, tiny creature."), 0));
                                            //instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("I'll never feel the power I once had, but this is something to sustain an old soul."), 0));
                                            //instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("I could read a bit of Five Pebbles in this neuron before formatting it.<LINE>A ghost left from his processing routines."), 0));
                                            //instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("Erratic... Pulse. \"Erratic Pulse.\" I wonder what that means."), 0));
                                        }
                                        else
                                        {
                                            instance.LoadEventsFromFile(19);
                                            //instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("I am grateful - the relief is indescribable!"), 0));
                                            //instance.events.Add(new Conversation.TextEvent(instance, 0, "...", 0));
                                            //instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("I could read a bit of Five Pebbles in this neuron before formatting it. His condition has severely deteriorated since last I<LINE>heard of him. The frustration he feels is profound, and that angst has seeped into every part of him, every neuron. "), 0));
                                            //instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("We were supposed to help everyone, you know. Everything. That was our purpose: a great gift to the lesser beings of the world. <LINE>When facing our inability to do so, we all reacted differently. Many with madness."), 0));
                                            //instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("But even back when we were all more or less connected there were those who reacted to their task with anger.<LINE>I can only imagine they are angrier now, alone in their cans, left only with their insatiable drive. "), 0));
                                            //instance.events.Add(new Conversation.TextEvent(instance, 0, instance.Translate("But to be honest, I don't know how many of us are still alive at this point."), 0));
                                        }
                                    }
                                    else if (instance.State.neuronGiveConversationCounter == 1)
                                    {
                                        instance.events.Add(new Conversation.TextEvent(instance, 30, instance.Translate("You get these at Five Pebbles'?<LINE>Thank you so much. I'm sure he won't mind."), 10));
                                        instance.events.Add(new Conversation.TextEvent(instance, 10, "...", 0));
                                        instance.events.Add(new Conversation.TextEvent(instance, 10, LancerMod.Translate("Or actually I'm sure he would, but he has so many of these~<LINE>it doesn't do him any difference.<LINE>For me though, it does! Thank you, tiny creature!"), 0));
                                    }
                                    else
                                    {
                                        switch (UnityEngine.Random.Range(0, 4))
                                        {
                                            case 0:
                                                instance.events.Add(new Conversation.TextEvent(instance, 30, instance.Translate("Thank you, again. I feel wonderful."), 10));
                                                break;

                                            case 1:
                                                instance.events.Add(new Conversation.TextEvent(instance, 30, instance.Translate("Thank you so very much!"), 10));
                                                break;

                                            case 2:
                                                instance.events.Add(new Conversation.TextEvent(instance, 30, instance.Translate("It is strange... I'm remembering myself, but also... him."), 10));
                                                break;

                                            default:
                                                instance.events.Add(new Conversation.TextEvent(instance, 30, LancerMod.Translate("Thank you tiny creature... Sincerely."), 10));
                                                break;
                                        }
                                    }
                                    instance.State.neuronGiveConversationCounter++;
                                }
                                break;
                        }
                        instance.slOracleBehaviorHasMark.respondToNeuronFromNoSpeakMode = false;
                        break;
                    }
                default:
                    orig.Invoke(instance);
                    break;
            }
        }
    }
}