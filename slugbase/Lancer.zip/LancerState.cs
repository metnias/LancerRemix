﻿namespace Lancer
{
    public static partial class PlayerPatch
    {
        public struct LancerState
        {
            public byte pull, lanceGrasp, delay, fire;
            public BodyChunk corpseChunk;
            public int polish;
            public Rock polishRock;
            public Spear polishSpear, firedSpear;
            public MaskOnHorn mask;
            public bool postponeDeath;
            public bool eatObj;

            public int horn; public bool hornOverlay;
        }
    }
}