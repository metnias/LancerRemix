﻿using System;
using System.IO;
using System.Reflection;
using UnityEngine;

namespace Lancer
{
    public static class DataManager
    {
        public static byte[] ReadBytes(string pngName)
        {
            var assembly = Assembly.GetExecutingAssembly();
            string resourceName = string.Concat("Lancer.Illustrations.", pngName, ".txt");
            string result;
            byte[] bytes;
            // Debug.Log(string.Concat("ReadBytes: ", resourceName));

            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            using (StreamReader reader = new StreamReader(stream))
            { result = reader.ReadToEnd(); }
            bytes = System.Convert.FromBase64String(result);

            return bytes;
        }

        public static void EncodeExternalPNG()
        {
            string[] files = Directory.GetFiles(Path.Combine(Directory.GetParent(Application.dataPath).ToString(), "encode") + Path.DirectorySeparatorChar.ToString(), "*.png", SearchOption.TopDirectoryOnly);
            foreach (string path in files)
            {
                try
                {
                    byte[] bytes = File.ReadAllBytes(path);
                    string encode = System.Convert.ToBase64String(bytes);
                    string newPath = path.Replace("png", "txt");

                    File.WriteAllText(newPath, encode);
                }
#pragma warning disable CA1031 // Do not catch general exception types
                catch (Exception ex)
                {
                    Debug.LogError(string.Concat("Error while encoding ", path));
                    Debug.LogError(ex);
                }
            }
        }

        public static void LogAllResources()
        {
            var assembly = Assembly.GetExecutingAssembly();

            string[] names = assembly.GetManifestResourceNames();
            Debug.Log("Log All Resources: ");
            foreach (string name in names) { Debug.Log(name); }
        }
    }
}