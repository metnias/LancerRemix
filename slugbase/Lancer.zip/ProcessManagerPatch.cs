﻿using RWCustom;
using System;
using System.IO;

namespace Lancer
{
    public static class ProcessManagerPatch
    {
        public static void Patch()
        {
            On.ProcessManager.SwitchMainProcess += new On.ProcessManager.hook_SwitchMainProcess(SwitchProcessPatch);
            On.OverWorld.LoadWorld += new On.OverWorld.hook_LoadWorld(LoadWorldPatch);
            On.OverWorld.GateRequestsSwitchInitiation += new On.OverWorld.hook_GateRequestsSwitchInitiation(GateSwitchPatch);
            On.RegionGate.ctor += new On.RegionGate.hook_ctor(RegionGateCtorPatch);
            On.ArenaGameSession.PlayersStillActive += new On.ArenaGameSession.hook_PlayersStillActive(PlayersStillActivePatch);
        }

        public static void SwitchProcessPatch(On.ProcessManager.orig_SwitchMainProcess orig, ProcessManager pm, ProcessManager.ProcessID ID)
        {
            orig.Invoke(pm, ID);
            if (pm.currentMainLoop != null && ID != ProcessManager.ProcessID.Game)
            { //Garbage Collect
                LancerScript.GarbageCollect();
            }
        }

        public static void LoadWorldPatch(On.OverWorld.orig_LoadWorld orig, OverWorld world, string worldName, int playerCharacterNumber, bool singleRoomWorld)
        {
            int n = playerCharacterNumber;
            if (LancerMod.IsLancer && !singleRoomWorld && n == 1)
            { n = 2; } // Hunter World for Lonk
            orig.Invoke(world, worldName, n, singleRoomWorld);
            if (!singleRoomWorld && playerCharacterNumber == 1)
            {
                if (!(world.game.session as StoryGameSession).saveState.guideOverseerDead && !(world.game.session as StoryGameSession).saveState.miscWorldSaveData.playerGuideState.angryWithPlayer && UnityEngine.Random.value < world.activeWorld.region.regionParams.playerGuideOverseerSpawnChance)
                {
                    WorldCoordinate worldCoordinate = new WorldCoordinate(world.activeWorld.offScreenDen.index, -1, -1, 0);
                    if (world.activeWorld.region.name == "SU")
                    {
                        worldCoordinate = new WorldCoordinate(world.activeWorld.GetAbstractRoom("SU_C04").index, 137, 17, 0);
                    }
                    AbstractCreature abstractCreature = new AbstractCreature(world.activeWorld, StaticWorld.GetCreatureTemplate(CreatureTemplate.Type.Overseer), null, worldCoordinate, new EntityID(-1, 5));
                    if (world.activeWorld.GetAbstractRoom(worldCoordinate).offScreenDen)
                    {
                        world.activeWorld.GetAbstractRoom(worldCoordinate).entitiesInDens.Add(abstractCreature);
                    }
                    else
                    {
                        world.activeWorld.GetAbstractRoom(worldCoordinate).AddEntity(abstractCreature);
                    }
                    (abstractCreature.abstractAI as OverseerAbstractAI).SetAsPlayerGuide();
                }
            }
        }

        public static void GateSwitchPatch(On.OverWorld.orig_GateRequestsSwitchInitiation orig, OverWorld world, RegionGate reportBackToGate)
        {
            bool flag = false;
            if (LancerMod.IsLancer && world.PlayerCharacterNumber == 1)
            {
                flag = true; world.game.GetStorySession.saveStateNumber = 2;
            }
            orig.Invoke(world, reportBackToGate);
            if (flag) { world.game.GetStorySession.saveStateNumber = 1; }
        }

        public static void RegionGateCtorPatch(On.RegionGate.orig_ctor orig, RegionGate gate, Room room)
        {
            orig.Invoke(gate, room);
            if (LancerMod.IsLancer && room.game.StoryCharacter == 1 && !File.Exists(Custom.RootFolderDirectory() + "nifflasmode.txt"))
            { gate.unlocked = false; }
        }

        public static int PlayersStillActivePatch(On.ArenaGameSession.orig_PlayersStillActive orig, ArenaGameSession session, bool addToAliveTime, bool dontCountSandboxLosers)
        {
            int num = 0;
            for (int i = 0; i < session.Players.Count; i++)
            {
                bool flag = true;
                if (!session.Players[i].state.alive)
                {
                    if (session.Players[i].realizedCreature == null) { flag = false; }
                    else if (session.Players[i].realizedCreature.dead) { flag = false; }
                }
                if (flag && session.exitManager != null && session.exitManager.IsPlayerInDen(session.Players[i]))
                { flag = false; }
                if (flag && session.Players[i].realizedCreature != null && (session.Players[i].realizedCreature as Player).dangerGrasp != null)
                { //modded part
                    if (!LancerMod.IsMelee) { flag = false; }
                    else if ((session.Players[i].realizedCreature as Player).dangerGraspTime >= 60) { flag = false; }
                }
                if (flag)
                {
                    for (int j = 0; j < session.arenaSitting.players.Count; j++)
                    {
                        if ((session.Players[i].state as PlayerState).playerNumber == session.arenaSitting.players[j].playerNumber)
                        {
                            if (session.Players[i].Room == session.game.world.offScreenDen && session.arenaSitting.players[j].hasEnteredGameArea)
                            { flag = false; }
                            if (addToAliveTime && flag && !session.sessionEnded)
                            { session.arenaSitting.players[j].timeAlive++; }
                            if (dontCountSandboxLosers && session.arenaSitting.players[j].sandboxWin < 0)
                            { flag = false; }
                            break;
                        }
                    }
                }
                if (flag) { num++; }
            }
            return Math.Max(num, orig.Invoke(session, addToAliveTime, dontCountSandboxLosers));
        }
    }
}