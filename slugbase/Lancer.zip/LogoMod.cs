﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Text;
using Menu;
using OptionalUI;
using Partiality.Modloader;
using RWCustom;
using UnityEngine;

namespace LogoKoreanPatch
{
    public class LogoMod : PartialityMod
    {
        public LogoMod()
        {
            this.ModID = "TitleKorSwap";
            this.Version = "0910";
            this.author = "2A03FISH, topicular";
        }

        private static string[] LogoIllusts;
        private static string[] TransIllusts;
        private Type _oiType;

        public static bool useLogo, useTrans;

        public override void OnEnable()
        {
            base.OnEnable();
            useLogo = true; useTrans = true;
            //DataManager.EncodeExternalPNG();
            //DataManager.LogAllResources();
            LogoIllusts = new string[] {
                "Intro_Roll_A",
                "Intro_Roll_C",
                "MainTitle",
                "MainTitle2",
                "MainTitleBevel",
                "MainTitleShadow"
            };
            TransIllusts = new string[] {
                "CompetitiveShadow",
                "CompetitiveTitle",
                "SandboxShadow",
                "SandboxTitle",
                "Title_CC",
                "Title_CC_Shadow",
                "Title_DS",
                "Title_DS_Shadow",
                "Title_GW",
                "Title_GW_Shadow",
                "Title_HI",
                "Title_HI_Shadow",
                "Title_LF",
                "Title_LF_Shadow",
                "Title_SB",
                "Title_SB_Shadow",
                "Title_SH",
                "Title_SH_Shadow",
                "Title_SI",
                "Title_SI_Shadow",
                "Title_SL",
                "Title_SL_Shadow",
                "Title_SS",
                "Title_SS_Shadow",
                "Title_SU",
                "Title_SU_Shadow",
                "Title_UW",
                "Title_UW_Shadow"
            };
            On.Menu.MenuIllustration.LoadFile_1 += new On.Menu.MenuIllustration.hook_LoadFile_1(IllustLoadFilePatch);
        }

        public OptionInterface LoadOI()
        {
            bool flag = this._oiType == null;
            if (flag) { this.LoadOIType(); }
            return (OptionInterface)Activator.CreateInstance(this._oiType, new object[] { this });
        }

        private void LoadOIType()
        {
            AssemblyName assemblyName = new AssemblyName("SplatConfig");
            AssemblyBuilder assemblyBuilder = AppDomain.CurrentDomain.DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess.Run);
            ModuleBuilder moduleBuilder = assemblyBuilder.DefineDynamicModule(assemblyName.Name);
            TypeBuilder typeBuilder = moduleBuilder.DefineType("SplatConfigProxy", TypeAttributes.Public);
            typeBuilder.SetParent(typeof(OptionInterface));
            ConstructorBuilder constructorBuilder = typeBuilder.DefineConstructor(MethodAttributes.Public, CallingConventions.Standard, new Type[] { typeof(PartialityMod) });
            ILGenerator ilgenerator = constructorBuilder.GetILGenerator();
            ilgenerator.Emit(OpCodes.Ldarg_0);
            ilgenerator.Emit(OpCodes.Ldarg_1);
            ilgenerator.Emit(OpCodes.Call, typeof(OptionInterface).GetConstructor(new Type[] { typeof(PartialityMod) }));
            ilgenerator.Emit(OpCodes.Ret);
            MethodAttributes attributes = MethodAttributes.FamANDAssem | MethodAttributes.Family | MethodAttributes.Virtual;
            MethodBuilder methodBuilder = typeBuilder.DefineMethod("Initialize", attributes);
            ilgenerator = methodBuilder.GetILGenerator();
            ilgenerator.Emit(OpCodes.Ldarg_0);
            ilgenerator.Emit(OpCodes.Call, typeof(LogoConfig).GetMethod("Initialize"));
            ilgenerator.Emit(OpCodes.Ret);
            MethodBuilder methodBuilder2 = typeBuilder.DefineMethod("ConfigOnChange", attributes);
            ilgenerator = methodBuilder2.GetILGenerator();
            ilgenerator.Emit(OpCodes.Call, typeof(LogoConfig).GetMethod("ConfigOnChange"));
            ilgenerator.Emit(OpCodes.Ret);
            //MethodBuilder methodBuilder3 = typeBuilder.DefineMethod("Signal", attributes, typeof(void), new Type[] { typeof(UItrigger), typeof(string) });
            //ilgenerator = methodBuilder3.GetILGenerator();
            //ilgenerator.Emit(OpCodes.Ldarg_0);
            //ilgenerator.Emit(OpCodes.Ldarg_1);
            //ilgenerator.Emit(OpCodes.Ldarg_2);
            //ilgenerator.Emit(OpCodes.Call, typeof(WingConfig).GetMethod("Signal"));
            //ilgenerator.Emit(OpCodes.Ret);
            this._oiType = typeBuilder.CreateType();
        }

        private static void IllustLoadFilePatch(On.Menu.MenuIllustration.orig_LoadFile_1 orig, MenuIllustration illust, string folder)
        {
            if (folder == "Illustrations")
            {
                if (useLogo && LogoIllusts.Contains(illust.fileName) ||
                   useTrans && TransIllusts.Contains(illust.fileName))
                { CustomIllustLoad(illust); return; }
            }
            orig.Invoke(illust, folder);
        }

        private static void CustomIllustLoad(MenuIllustration illust)
        {
            string tempPath = string.Concat(Custom.RootFolderDirectory(), illust.fileName, ".png");
            File.WriteAllBytes(tempPath, DataManager.ReadBytes(illust.fileName));
            illust.www = new WWW(string.Concat("file:///", tempPath));

            //illust.www = new WWW(string.Concat("file:///", SporeMod.resourcePath, folder, Path.DirectorySeparatorChar, illust.fileName, ".png"));
            illust.texture = new Texture2D(1, 1, TextureFormat.ARGB32, false) { wrapMode = TextureWrapMode.Clamp };
            if (illust.crispPixels)
            {
                illust.texture.anisoLevel = 0;
                illust.texture.filterMode = FilterMode.Point;
            }
            illust.www.LoadImageIntoTexture(illust.texture);
            HeavyTexturesCache.LoadAndCacheAtlasFromTexture(illust.fileName, illust.texture);
            illust.www = null;
            File.Delete(tempPath);
        }
    }
}