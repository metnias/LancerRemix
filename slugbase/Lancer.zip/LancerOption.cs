using OptionalUI;
using UnityEngine;

namespace Lancer
{
    public class LancerOption : OptionInterface
    {
        public LancerOption() : base(mod: LancerScript.mod)
        {
#pragma warning disable CA1031 // Do not catch general exception types
            try
            {
                this.transFile = "Lancer.Translation.txt";
                LancerMod.config.translate = true;
            }
            catch { LancerMod.config.translate = false; }
#pragma warning restore CA1031 // Do not catch general exception types
        }

        public override bool Configuable()
        {
            return true;
        }

        public override void Update(float dt)
        {
            base.Update(dt);

        CpkrSetup:
            cpkrSurv.Hide(); cpkrSurv.greyedOut = true;
            cpkrMonk.Hide(); cpkrMonk.greyedOut = true;
            cpkrHunt.Hide(); cpkrHunt.greyedOut = true;
            cpkrWtch.Hide(); cpkrWtch.greyedOut = true;
            switch (radioGroupCpkr.valueInt)
            {
                default:
                case 0:
                    cpkrSurv.Show(); cpkrSurv.greyedOut = !checkHorn.valueBool;
                    labelCpkrRadio.text = LancerMod.Translate("Survivor Horn Colour");
                    break;

                case 1:
                    cpkrMonk.Show(); cpkrMonk.greyedOut = !checkHorn.valueBool;
                    labelCpkrRadio.text = LancerMod.Translate("Monk Horn Colour");
                    break;

                case 2:
                    cpkrHunt.Show(); cpkrHunt.greyedOut = !checkHorn.valueBool;
                    labelCpkrRadio.text = LancerMod.Translate("Hunter Horn Colour");
                    break;

                case 3:
                    cpkrWtch.Show(); cpkrWtch.greyedOut = !checkHorn.valueBool;
                    labelCpkrRadio.text = LancerMod.Translate("Nightcat Horn Colour");
                    break;
            }
            radioGroupCpkr.greyedOut = !checkHorn.valueBool;
            checkCpkrReset.greyedOut = !checkHorn.valueBool;
            labelCpkrRadio.color = checkHorn.valueBool
                ? Menu.Menu.MenuRGB(Menu.Menu.MenuColors.MediumGrey) : Menu.Menu.MenuRGB(Menu.Menu.MenuColors.VeryDarkGrey);

            if (checkDefLancer.valueBool)
            {
                checkDefLancer.valueBool = false;
                checkLance.valueBool = true;
                checkPup.valueBool = true;
                checkPullSpear.valueBool = true;
                checkSpearGrab.valueBool = false;
                checkHorn.valueBool = true;
            }
            if (checkDefVan.valueBool)
            {
                checkDefVan.valueBool = false;
                checkLance.valueBool = false;
                checkPup.valueBool = false;
                checkPullSpear.valueBool = false;
                checkSpearGrab.valueBool = false;
                checkHorn.valueBool = false;
            }
            if (checkCpkrReset.valueBool)
            {
                checkCpkrReset.valueBool = false;
                cpkrSurv.valueColor = PlayerGraphicsPatch.defaultHornColor[0];
                cpkrMonk.valueColor = PlayerGraphicsPatch.defaultHornColor[1];
                cpkrHunt.valueColor = PlayerGraphicsPatch.defaultHornColor[2];
                cpkrWtch.valueColor = PlayerGraphicsPatch.defaultHornColor[3];
                radioGroupCpkr.valueInt = 0;
                goto CpkrSetup;
            }
            bool grape = !checkLance.valueBool && !checkPup.valueBool && checkPullSpear.valueBool
                && checkSpearGrab.valueBool && !checkHorn.valueBool;
            if (grape)
            {
                labelID.text = "Grapecat";
                labelDsc.text = LancerMod.Translate("He is purple, because purple is the best colour");
                labelAuthor.text = "by Josbird";
                labelCoauthor.text = "Remake to Partiality by topicular";
            }
            else
            {
                labelID.text = textid;
                labelDsc.text = LancerMod.Translate(textDesc);
                labelAuthor.text = textAuthor;
                labelCoauthor.text = LancerMod.Translate(textCoathr);
            }
        }

        private const string textid = "Lancer Mod";
        private const string textDesc = "Slugpup with a horn that attack in melee with spears";
        private const string textAuthor = "by topicular";
        private const string textCoathr = "Testing - 12 Steps . . . Lores - Empathy Module";

        public override void Initialize()
        {
            base.Initialize();

            Tabs = new OpTab[1];
            Tabs[0] = new OpTab();

            labelID = new OpLabel(new Vector2(100f, 550f), new Vector2(400f, 40f), textid, FLabelAlignment.Center, true);
            labelDsc = new OpLabel(new Vector2(100f, 520f), new Vector2(400f, 20f), LancerMod.Translate(textDesc));
            string ver = LancerScript.mod.Version.Substring(0, 1) + "." + LancerScript.mod.Version.Substring(1, 1) + "."
                + LancerScript.mod.Version.Substring(2, 1) + "." + LancerScript.mod.Version.Substring(3, 1);
            labelVersion = new OpLabel(new Vector2(100f, 500f), new Vector2(200f, 20f), string.Concat("Version: ", ver), FLabelAlignment.Left);
            labelAuthor = new OpLabel(new Vector2(300f, 500f), new Vector2(200f, 20f), textAuthor, FLabelAlignment.Right);
            labelCoauthor = new OpLabel(new Vector2(100f, 480f), new Vector2(400f, 20f), LancerMod.Translate(textCoathr));
            Tabs[0].AddItems(labelID, labelDsc, labelVersion, labelAuthor, labelCoauthor);

            checkDefLancer = new OpCheckBox(new Vector2(40f, 450f), "_DefLancer", false)
            { description = LancerMod.Translate("Reset Configuation to Lancer Preset") };
            labelDefLancer = new OpLabel(new Vector2(80f, 452f), new Vector2(80f, 20f), LancerMod.Translate("Lancer Preset"), FLabelAlignment.Left)
            { description = LancerMod.Translate("Reset Configuation to Lancer Preset") };
            checkDefVan = new OpCheckBox(new Vector2(220f, 450f), "_DefVan", false)
            { description = LancerMod.Translate("Reset Configuation to Vanilla Preset") };
            labelDefVan = new OpLabel(new Vector2(260f, 452f), new Vector2(80f, 20f), LancerMod.Translate("Vanilla Preset"), FLabelAlignment.Left)
            { description = LancerMod.Translate("Reset Configuation to Vanilla Preset") };
            Tabs[0].AddItems(checkDefLancer, labelDefLancer, checkDefVan, labelDefVan);

            checkLance = new OpCheckBox(new Vector2(424f, 428f), "Lance", true)
            { description = LancerMod.Translate("Attacks in melee with spears when enabled") };
            labelLance = new OpLabel(new Vector2(460f, 430f), new Vector2(90f, 20f), LancerMod.Translate("Lance Attack"), FLabelAlignment.Left)
            { description = LancerMod.Translate("Attacks in melee with spears when enabled") };
            checkPup = new OpCheckBox(new Vector2(424f, 378f), "Pup", true)
            { description = LancerMod.Translate("Slugcat becomes a pup when enabled") };
            labelPup = new OpLabel(new Vector2(460f, 380f), new Vector2(90f, 20f), LancerMod.Translate("Slugpup"), FLabelAlignment.Left)
            { description = LancerMod.Translate("Slugcat becomes a pup when enabled") };
            checkPullSpear = new OpCheckBox(new Vector2(424f, 338f), "PullSpear", true)
            { description = LancerMod.Translate("Can pull embeded spears out of walls and floors when enabled") };
            labelPullSpear = new OpLabel(new Vector2(460f, 340f), new Vector2(110f, 20f), LancerMod.Translate("Pull Embeded Spears"), FLabelAlignment.Left)
            { description = LancerMod.Translate("Can pull embeded spears out of walls and floors when enabled") };
            checkSpearGrab = new OpCheckBox(new Vector2(424f, 298f), "SpearGrab", false)
            { description = LancerMod.Translate("Allow holding a spear in single handed when enabled") };
            labelSpearGrab = new OpLabel(new Vector2(460f, 300f), new Vector2(90f, 20f), LancerMod.Translate("One Hand Spear"), FLabelAlignment.Left)
            { description = LancerMod.Translate("Allow holding a spear in single handed when enabled") };
            Tabs[0].AddItems(checkLance, labelLance, checkPup, labelPup, checkPullSpear, labelPullSpear, checkSpearGrab, labelSpearGrab);

            rectHorn = new OpRect(new Vector2(400f, 10f), new Vector2(190f, 270f))
            { doesBump = true };
            checkHorn = new OpCheckBox(new Vector2(424f, 238f), "Horn", true)
            { description = LancerMod.Translate("Slugcat will have a horn when enabled") };
            labelHornClr = new OpLabel(new Vector2(450f, 240f), new Vector2(90f, 20f), LancerMod.Translate("Lancer Horn"))
            { description = LancerMod.Translate("Slugcat will have a horn when enabled") };
            cpkrSurv = new OpColorPicker(new Vector2(420f, 80f), "HornSurv", OpColorPicker.ColorToHex(PlayerGraphicsPatch.defaultHornColor[0]));
            cpkrMonk = new OpColorPicker(new Vector2(420f, 80f), "HornMonk", OpColorPicker.ColorToHex(PlayerGraphicsPatch.defaultHornColor[1]));
            cpkrHunt = new OpColorPicker(new Vector2(420f, 80f), "HornHunt", OpColorPicker.ColorToHex(PlayerGraphicsPatch.defaultHornColor[2]));
            cpkrWtch = new OpColorPicker(new Vector2(420f, 80f), "HornWtch", OpColorPicker.ColorToHex(PlayerGraphicsPatch.defaultHornColor[3]));
            labelCpkrRadio = new OpLabel(new Vector2(420f, 60f), new Vector2(150f, 20f), "");
            radioGroupCpkr = new OpRadioButtonGroup("_CpkrHorn", 0);
            radioSurv = new OpRadioButton(new Vector2(420f, 30f))
            { description = LancerMod.Translate("Survivor Horn Colour") };
            radioMonk = new OpRadioButton(new Vector2(450f, 30f))
            { description = LancerMod.Translate("Monk Horn Colour") };
            radioHunt = new OpRadioButton(new Vector2(480f, 30f))
            { description = LancerMod.Translate("Hunter Horn Colour") };
            radioWtch = new OpRadioButton(new Vector2(510f, 30f))
            { description = LancerMod.Translate("Nightcat Horn Colour") };
            radioGroupCpkr.SetButtons(new OpRadioButton[]
            { radioSurv, radioMonk, radioHunt, radioWtch });
            checkCpkrReset = new OpCheckBox(new Vector2(546f, 30f), "_CpkrReset", false)
            { description = LancerMod.Translate("Reset Horn Colours to Default") };
            Tabs[0].AddItems(rectHorn, checkHorn, labelHornClr, cpkrSurv, cpkrMonk, cpkrHunt, cpkrWtch, labelCpkrRadio, radioGroupCpkr, radioSurv, radioMonk, radioHunt, radioWtch, checkCpkrReset);

            rectTuto = new OpRect(new Vector2(10f, 10f), new Vector2(370f, 430f));
            string tuto;
            tuto = "- " + LancerMod.Translate("The more you use spears, the more dull they get; Dull spears are more likely to stick to creatures.") + "\n";
            tuto += "- " + LancerMod.Translate("Hold UP and press PICK UP to pull out spears from creatures.") + "\n";
            tuto += "- " + LancerMod.Translate("Resharpen a spear with rocks by pressing PICK UP twice.") + "\n";
            tuto += "- " + LancerMod.Translate("Sharpening effect does not stack on top of itself.") + "\n";
            tuto += "- " + LancerMod.Translate("Sharpened spears have a small sparkling effect.") + "\n";
            tuto += "- " + LancerMod.Translate("Pinning a spear into the wall will make it notably dull; Sharpen the spear to make it usable again.");
            tuto += "- " + LancerMod.Translate("Perform a rocket jump by slide-boosting and backward throw with a spear.") + "\n";
            tuto += "- " + LancerMod.Translate("Slide throw with a spear for extra damage; Spear is guaranteed to get stuck.") + "\n";
            tuto += "- " + LancerMod.Translate("Hold PICK UP to wear vulture masks on your horn.") + "\n";
            tuto += "- " + LancerMod.Translate("Don't hold any spears to demask yourself.");
            labelTuto = new OpLabelLong(new Vector2(20f, 20f), new Vector2(350f, 410f), tuto);
            Tabs[0].AddItems(rectTuto, labelTuto);
        }

        public OpLabel labelID;
        public OpLabel labelDsc;
        public OpLabel labelVersion;
        public OpLabel labelAuthor;
        public OpLabel labelCoauthor;

        public OpCheckBox checkDefLancer;
        public OpLabel labelDefLancer;
        public OpCheckBox checkDefVan;
        public OpLabel labelDefVan;

        public OpCheckBox checkLance;
        public OpLabel labelLance;
        public OpCheckBox checkPup;
        public OpLabel labelPup;
        public OpCheckBox checkPullSpear;
        public OpLabel labelPullSpear;
        public OpCheckBox checkSpearGrab;
        public OpLabel labelSpearGrab;

        public OpRect rectHorn;
        public OpCheckBox checkHorn;
        public OpLabel labelHornClr;
        public OpColorPicker cpkrSurv;
        public OpColorPicker cpkrMonk;
        public OpColorPicker cpkrHunt;
        public OpColorPicker cpkrWtch;
        public OpLabel labelCpkrRadio;
        public OpRadioButtonGroup radioGroupCpkr;
        public OpRadioButton radioSurv;
        public OpRadioButton radioMonk;
        public OpRadioButton radioHunt;
        public OpRadioButton radioWtch;
        public OpCheckBox checkCpkrReset;

        public OpRect rectTuto;
        public OpLabelLong labelTuto;

        public override void ConfigOnChange()
        {
            radioGroupCpkr.valueInt = 0;
            base.ConfigOnChange();

            LancerMod.config.configMachine = true;
            LancerMod.config.disabled = false;
            LancerMod.config.hornColor = new Color[4];

            LancerMod.config.melee = config["Lance"] == "true";

            LancerMod.config.isPup = config["Pup"] == "true";
            LancerMod.config.canPullSpear = config["PullSpear"] == "true";
            LancerMod.config.spearGrability = config["SpearGrab"] == "true";
            LancerMod.config.hasHorn = config["Horn"] == "true";

            LancerMod.config.grape = !LancerMod.config.hasHorn && !LancerMod.config.isPup && !LancerMod.config.melee
                && LancerMod.config.canPullSpear && LancerMod.config.spearGrability;

            LancerMod.config.hornColor[0] = OpColorPicker.HexToColor(config["HornSurv"]);
            LancerMod.config.hornColor[1] = OpColorPicker.HexToColor(config["HornMonk"]);
            LancerMod.config.hornColor[2] = OpColorPicker.HexToColor(config["HornHunt"]);
            LancerMod.config.hornColor[3] = OpColorPicker.HexToColor(config["HornWtch"]);
        }
    }
}
